bl_info = {
    "name" : "Molecular Nodes",
    "author" : "Brady Johnston", 
    "description" : "A plugin and nodes for working with molecular data in Blender.",
    "blender" : (3, 0, 0),
    "version" : (0, 1, 2),
    "location" : "Perth, Australia",
    "waring" : "",
    "doc_url": "", 
    "tracker_url": "https://github.com/BradyAJohnston/MolecularNodes/issues", 
    "category" : "3D View" 
}

import bpy
import bpy.utils.previews

import bpy
import atomium
import bpy
import bpy
import os
import subprocess
import os


def string_to_int(value):
    if value.isdigit():
        return int(value)
    return 0


def string_to_icon(value):
    if value in bpy.types.UILayout.bl_rna.functions["prop"].parameters[
            "icon"].enum_items.keys():
        return bpy.types.UILayout.bl_rna.functions["prop"].parameters[
            "icon"].enum_items[value].value
    return string_to_int(value)


def icon_to_string(value):
    for icon in bpy.types.UILayout.bl_rna.functions["prop"].parameters[
            "icon"].enum_items:
        if icon.value == value:
            return icon.name
    return "NONE"


def enum_set_to_string(value):
    if type(value) == set:
        if len(value) > 0:
            return "[" + (", ").join(list(value)) + "]"
        return "[]"
    return value


def string_to_type(value, to_type, default):
    try:
        value = to_type(value)
    except:
        value = default
    return value


addon_keymaps = {}
_icons = None
nodetree = {}


class SNA_OT_Import_Protein_Fetch_Pdb_4Cf80(bpy.types.Operator):
    bl_idname = "sna.import_protein_fetch_pdb_4cf80"
    bl_label = "import_protein_fetch_pdb"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        sna_func_import_structure_EE5B6(bpy.context.scene.sna_pdb_code,
                                        bpy.context.scene.sna_nanometre_scale,
                                        True, bpy.context.scene.sna_pdb_path)
        return {"FINISHED"}

    def invoke(self, context, event):

        return context.window_manager.invoke_confirm(self, event)


class SNA_OT_Import_Protein_Local_Ecb16(bpy.types.Operator):
    bl_idname = "sna.import_protein_local_ecb16"
    bl_label = "import_protein_local"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        sna_func_import_structure_EE5B6(bpy.context.scene.sna_pdb_code,
                                        bpy.context.scene.sna_nanometre_scale,
                                        False, bpy.context.scene.sna_pdb_path)
        return {"FINISHED"}

    def invoke(self, context, event):

        return context.window_manager.invoke_confirm(self, event)


def sna_func_import_structure_EE5B6(pdb_code, nanometre_scale, fetch_pdb,
                                    pdb_path):
    pdb_code = pdb_code
    nanometre_scale = nanometre_scale
    fetch_pdb = fetch_pdb
    pdb_path = pdb_path
    import numpy as np
    import re
    atom_name_dict = {
        'C': 1,
        "C1'": 2,
        'C2': 3,
        "C2'": 4,
        "C3'": 5,
        'C4': 6,
        "C4'": 7,
        'C5': 8,
        "C5'": 9,
        'C6': 10,
        'C7': 11,
        'C8': 12,
        'CA': 13,
        'CB': 14,
        'CD': 15,
        'CD1': 16,
        'CD2': 17,
        'CE': 18,
        'CE1': 19,
        'CE2': 20,
        'CG': 21,
        'CG1': 22,
        'CG2': 23,
        'CZ': 24,
        'N': 25,
        'N1': 26,
        'N2': 27,
        'N3': 28,
        'N4': 29,
        'NZ': 30,
        'O': 31,
        'O2': 32,
        "O3'": 33,
        'O4': 34,
        "O4'": 35,
        "O5'": 36,
        'O6': 37,
        'OD1': 38,
        'OD2': 39,
        'OE1': 40,
        'OE2': 41,
        'OG': 42,
        'OG1': 43,
        'OH': 44,
        'OP1': 45,
        'OP2': 46,
        'OXT': 47,
        'P': 48,
        'SD': 49,
        'SG': 50
    }
    element_dict = {
        "H": {
            "atomic_number": 1,
            "radii": 0.53
        },
        "He": {
            "atomic_number": 2,
            "radii": 0.31
        },
        "Li": {
            "atomic_number": 3,
            "radii": 1.67
        },
        "Be": {
            "atomic_number": 4,
            "radii": 1.12
        },
        "B": {
            "atomic_number": 5,
            "radii": 0.87
        },
        "C": {
            "atomic_number": 6,
            "radii": 0.67
        },
        "N": {
            "atomic_number": 7,
            "radii": 0.56
        },
        "O": {
            "atomic_number": 8,
            "radii": 0.48
        },
        "F": {
            "atomic_number": 9,
            "radii": 0.42
        },
        "Ne": {
            "atomic_number": 10,
            "radii": 0.38
        },
        "Na": {
            "atomic_number": 11,
            "radii": 1.90
        },
        "Mg": {
            "atomic_number": 12,
            "radii": 1.45
        },
        "Al": {
            "atomic_number": 13,
            "radii": 1.18
        },
        "Si": {
            "atomic_number": 14,
            "radii": 1.11
        },
        "P": {
            "atomic_number": 15,
            "radii": 0.98
        },
        "S": {
            "atomic_number": 16,
            "radii": 0.88
        },
        "Cl": {
            "atomic_number": 17,
            "radii": 0.79
        },
        "Ar": {
            "atomic_number": 18,
            "radii": 0.71
        },
        "K": {
            "atomic_number": 19,
            "radii": 2.43
        },
        "Ca": {
            "atomic_number": 20,
            "radii": 1.9
        }
    }
    AA_dict = {
        # 20 naturally occurring amino acids
        "ALA": {
            "aa_number": 1,
            "aa_type": "polar",
            "aa_type_no": 1
        },
        "ARG": {
            "aa_number": 2,
            "aa_type": "polar",
            "aa_type_no": 1
        },
        "ASN": {
            "aa_number": 3,
            "aa_type": "polar",
            "aa_type_no": 1
        },
        "ASP": {
            "aa_number": 4,
            "aa_type": "polar",
            "aa_type_no": 1
        },
        "CYS": {
            "aa_number": 5,
            "aa_type": "polar",
            "aa_type_no": 1
        },
        "GLU": {
            "aa_number": 6,
            "aa_type": "polar",
            "aa_type_no": 1
        },
        "GLN": {
            "aa_number": 7,
            "aa_type": "polar",
            "aa_type_no": 1
        },
        "GLY": {
            "aa_number": 8,
            "aa_type": "polar",
            "aa_type_no": 1
        },
        "HIS": {
            "aa_number": 9,
            "aa_type": "polar",
            "aa_type_no": 1
        },
        "ILE": {
            "aa_number": 10,
            "aa_type": "polar",
            "aa_type_no": 1
        },
        "LEU": {
            "aa_number": 11,
            "aa_type": "polar",
            "aa_type_no": 1
        },
        "LYS": {
            "aa_number": 12,
            "aa_type": "polar",
            "aa_type_no": 1
        },
        "MET": {
            "aa_number": 13,
            "aa_type": "polar",
            "aa_type_no": 1
        },
        "PHE": {
            "aa_number": 14,
            "aa_type": "polar",
            "aa_type_no": 1
        },
        "PRO": {
            "aa_number": 15,
            "aa_type": "polar",
            "aa_type_no": 1
        },
        "SER": {
            "aa_number": 16,
            "aa_type": "polar",
            "aa_type_no": 1
        },
        "THR": {
            "aa_number": 17,
            "aa_type": "polar",
            "aa_type_no": 1
        },
        "TRP": {
            "aa_number": 18,
            "aa_type": "polar",
            "aa_type_no": 1
        },
        "TYR": {
            "aa_number": 19,
            "aa_type": "polar",
            "aa_type_no": 1
        },
        "VAL": {
            "aa_number": 20,
            "aa_type": "polar",
            "aa_type_no": 1
        },
        # unknown? Came up in one of the structures, haven't looked into it yet
        # TODO look into it!
        "UNK": {
            "aa_number": 21,
            "aa_type": "unkown",
            "aa_type_no": 1
        },
        ## nucleic acids
        ### DNA
        "DC": {
            "aa_number": 31,
            "aa_type": "unkown",
            "aa_type_no": 1
        },
        "DG": {
            "aa_number": 32,
            "aa_type": "unkown",
            "aa_type_no": 1
        },
        "DA": {
            "aa_number": 33,
            "aa_type": "unkown",
            "aa_type_no": 1
        },
        "DT": {
            "aa_number": 34,
            "aa_type": "unkown",
            "aa_type_no": 1
        },
        ### RNA
        "C": {
            "aa_number": 41,
            "aa_type": "unkown",
            "aa_type_no": 1
        },
        "G": {
            "aa_number": 42,
            "aa_type": "unkown",
            "aa_type_no": 1
        },
        "A": {
            "aa_number": 43,
            "aa_type": "unkown",
            "aa_type_no": 1
        },
        "U": {
            "aa_number": 44,
            "aa_type": "unkown",
            "aa_type_no": 1
        }
    }
    pdb_id = pdb_code
    one_nanometre_size_in_metres = nanometre_scale * 0.1
    # download the required model
    if (fetch_pdb):
        pdb = atomium.fetch(pdb_id)
    else:
        pdb = atomium.open(pdb_path)
    #pdb = atomium.open("C:\\Users\\BradyJohnston\\Desktop\\atp-frames.pdb")
    # check the number of models in the file
    n_models = len(pdb.models)
    first_model = pdb.models[0]
    n_atoms = len(first_model.atoms())
    all_chains = first_model.chains()
    # contains the atom number in the PDB file, acts as the index for everything.
    atom_id = []
    # contains the XYZ coordinates for the atom
    atom_location = []
    # contains the character sumbol of the element for the atom, i.e. 'H' for Hydrogen
    # and 'C' for Carbon
    atom_element_char = []
    # contains the atomic number of the number, has to be matched later against a
    # dictionary as the pip release of atomium doesn't currently have quick-access
    # to the atomic number, only the symbol
    atom_element_num = []
    # contains the name of the atom, which varies depending on where the atom appears
    # in the residue, C, C1' etc, with the second list being the numeric encoding of
    # this for use in geometry nodes
    atom_name_char = []
    atom_name_num = []
    # contains the letter code that is the representative of the chain that the
    # residue is part of, with the second list being the numeric encoding of this
    # for use in geometry nodes
    atom_chain_char = []
    atom_chain_num = []
    # contains the 3-letter codes that ID The AA side chain the atom is a part of,
    # or the single or two-letter codes for nucleic acids, with the second list
    # being the numeric encoding of this for use in geometry nodes
    atom_aa_id_char = []
    atom_aa_id_number = []
    # contains the integer representing the residue number in the sequence of the
    # protein that the atom is part of
    atom_aa_sequence_number = []
    # contains the b-factor for each atom, which is a representation of how
    # static the atom is when part of the overall structure
    atom_b_factor = []
    # contains TRUE / FALSE for whether the atom is part of the backbone
    atom_is_backbone = []
    # contains True / False for whether the atom is part of a sidechain
    atom_is_sidechain = []

    def try_append(list, value, value_on_fail=0):
        """
        Tries to append the value to the list, and adds instead the value on fail
        instead if a lookup into one of the dictionaries has failed.
        """
        try:
            list.append(value)
        except:
            list.appen(value_on_fail)

    for chain in first_model.chains():
        current_chain = chain.id
        for res in chain.residues():
            current_aa_id_char = res.name
            current_aa_sequence_number = int(
                re.findall(r"\d+",
                           res.id.split(".")[1])[0])
            for atom in res.atoms():
                # TODO remove the old list appends if everything is working properly
                try_append(atom_id, atom.id)
                # atom_id.append(atom.id)
                try_append(atom_location, atom.location)
                # atom_location.append(atom.location)
                try_append(atom_element_char, atom.element)
                # atom_element_char.append(atom.element)
                try_append(atom_element_num,
                           element_dict[atom.element]["atomic_number"])
                # atom_element_num.append(element_dict[atom.element]["atomic_number"])
                try_append(atom_name_char, atom.name)
                # atom_name_char.append(atom.name)
                try_append(atom_chain_char, current_chain)
                # atom_chain_char.append(current_chain)
                try_append(atom_aa_sequence_number, current_aa_sequence_number)
                # atom_aa_sequence_number.append(current_aa_sequence_number)
                try_append(atom_aa_id_char, current_aa_id_char)
                # atom_aa_id_char.append(current_aa_id_char)
                try_append(atom_b_factor, atom.bvalue)
                # atom_b_factor.append(atom.bvalue)
                try_append(atom_aa_id_number,
                           AA_dict[current_aa_id_char]["aa_number"])
                # atom_aa_id_number.append(AA_dict[current_aa_id_char]["aa_number"])
                try_append(atom_is_backbone, int(atom.is_backbone))
                try_append(atom_is_sidechain, int(atom.is_side_chain))
    # turn all of the lists into numpy arrays, so that they can be rearranged based
    # on the atom indices created with np.argsort()
    atom_id = np.array(atom_id)
    atom_location = np.array(atom_location)
    atom_element_char = np.array(atom_element_char)
    atom_element_num = np.array(atom_element_num)
    atom_name_char = np.array(atom_name_char)
    # atom_name_num = np.array(atom_name_num)
    atom_chain_char = np.array(atom_chain_char)
    # atom_chain_num = np.array(atom_chain_num)
    atom_aa_id_char = np.array(atom_aa_id_char)
    atom_aa_id_number = np.array(atom_aa_id_number)
    atom_aa_sequence_number = np.array(atom_aa_sequence_number)
    atom_b_factor = np.array(atom_b_factor)
    atom_is_backbone = np.array(atom_is_backbone)
    atom_is_sidechain = np.array(atom_is_sidechain)
    inds = atom_id.argsort()
    # rearrange all of the arrays based on the indices, so that all values
    # match properly, and the atoms are in ascending order
    atom_id = atom_id[inds]
    atom_location = atom_location[inds]
    atom_element_char = atom_element_char[inds]
    atom_element_num = atom_element_num[inds]
    atom_name_char = atom_name_char[inds]
    # atom_name_num = atom_name_num[inds]
    atom_chain_char = atom_chain_char[inds]
    # atom_chain_num = atom_chain_num[inds]
    atom_aa_id_char = atom_aa_id_char[inds]
    atom_aa_id_number = atom_aa_id_number[inds]
    atom_aa_sequence_number = atom_aa_sequence_number[inds]
    atom_b_factor = atom_b_factor[inds]
    atom_is_backbone = atom_is_backbone[inds]
    atom_is_sidechain = atom_is_sidechain[inds]
    unique_chains = np.array(list(set(atom_chain_char)))
    chain_inds = unique_chains.argsort()
    unique_chains = unique_chains[chain_inds]
    atom_chain_num = list(
        map(lambda x: int(np.where(x == unique_chains)[0]), atom_chain_char))
    atom_chain_num = np.array(atom_chain_num)
    unique_atoms = np.array(list(set(atom_name_char)))
    unique_atoms_inds = unique_atoms.argsort()
    unique_atoms = unique_atoms[unique_atoms_inds]

    def try_lookup(dict, key, value_on_fail=0):
        """
        Try looking up the value from the key in the dictionary, 
        otherwise return the value on fail so that things can keep moving
        """
        try:
            return dict[key]
        except:
            return value_on_fail

    atom_name_num = list(
        map(lambda x: int(try_lookup(atom_name_dict, x)), atom_name_char))
    atom_name_num = np.array(atom_name_num)

    def create_model(name, collection, locations, bonds=[], faces=[]):
        """
        Creates a mesh with the given name in the given collection, from the supplied
        values for the locationso of vertices, and if supplied, bonds and faces.
        """
        # create a new mesh
        atom_mesh = bpy.data.meshes.new(name)
        atom_mesh.from_pydata(locations, bonds, faces)
        new_object = bpy.data.objects.new(name, atom_mesh)
        collection.objects.link(new_object)

    def create_properties_model(name, collection, prop_x, prop_y, prop_z):
        """
        Creates a mesh that will act as a look up table for properties about the atoms
        in the actual mesh that will be created.
        """

        def get_value(vec, x):
            try:
                return vec[x]
            except:
                return 0

        create_model(name=name,
                     collection=collection,
                     locations=list(
                         map(
                             lambda x: [
                                 get_value(prop_x, x),
                                 get_value(prop_y, x),
                                 get_value(prop_z, x)
                             ], range(len(atom_aa_sequence_number) - 1))))

    def get_frame_positions(frame):
        all_atoms = frame.atoms()
        atom_id = list(map(lambda x: x.id, all_atoms))
        atom_location = list(map(lambda x: x.location, all_atoms))
        atom_id = np.array(atom_id)
        inds = atom_id.argsort()
        atom_id = atom_id[inds]
        atom_location = np.array(atom_location)
        atom_location = atom_location[inds]
        return atom_location

    col = bpy.data.collections.new(pdb_id)
    bpy.data.collections['Collection'].children.link(col)
    col_properties = bpy.data.collections.new(pdb_id + "_properties")
    col.children.link(col_properties)
    create_model(pdb_id,
                 collection=col,
                 locations=atom_location * one_nanometre_size_in_metres)
    # create the first properties model
    create_properties_model(
        name=pdb_id + "_properties_1",
        collection=col_properties,
        prop_x=atom_element_num,
        prop_y=atom_chain_num + 1,  # to have the first chain be indexed from 1
        prop_z=atom_name_num)
    create_properties_model(name=pdb_id + "_properties_2",
                            collection=col_properties,
                            prop_x=atom_aa_sequence_number,
                            prop_y=atom_id,
                            prop_z=atom_aa_id_number)
    create_properties_model(name=pdb_id + "_properties_3",
                            collection=col_properties,
                            prop_x=atom_b_factor,
                            prop_y=atom_is_backbone,
                            prop_z=atom_is_sidechain)
    if (n_models > 1):
        frames_collection = bpy.data.collections.new(pdb_id + "_frames")
        col.children.link(frames_collection)
        for frame in pdb.models:
            atom_location = get_frame_positions(frame)
            create_model(name="frame_" + pdb_id,
                         collection=frames_collection,
                         locations=atom_location *
                         one_nanometre_size_in_metres)
    self.report({'INFO'}, message=' '.join(['successfully imported.']))


def sna_add_to_node_mt_add_284D4(self, context):
    if not (not 'GeometryNodeTree' == bpy.context.area.spaces[0].tree_type):
        layout = self.layout
        layout.menu('SNA_MT_F5083', text='Molecular Nodes', icon_value=88)


class SNA_OT_Add_Test_Node_30300(bpy.types.Operator):
    bl_idname = "sna.add_test_node_30300"
    bl_label = "add_test_node"
    bl_description = "Some documentation for this operator!"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        sna_append_add_node_3229D('yet_another_node')
        return {"FINISHED"}

    def invoke(self, context, event):

        return self.execute(context)


class SNA_OT_Add_Another_Node_1163F(bpy.types.Operator):
    bl_idname = "sna.add_another_node_1163f"
    bl_label = "add_another_node"
    bl_description = "Some documentation for this operator!"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        sna_append_add_node_3229D('another_node')
        return {"FINISHED"}

    def invoke(self, context, event):

        return self.execute(context)


class SNA_MT_F5083(bpy.types.Menu):
    bl_idname = "SNA_MT_F5083"
    bl_label = "Testing"

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw(self, context):
        layout = self.layout.column_flow(columns=1)
        layout.menu('SNA_MT_43F2D', text='DNA', icon_value=206)


def sna_append_add_node_3229D(new_node):
    new_node = new_node
    need_to_append = None
    new_node = new_node
    need_to_append = False
    try:
        bpy.data.node_groups.get(new_node).name == new_node
    except:
        need_to_append = True
    if need_to_append:
        bpy.ops.wm.append(
            directory=os.path.join(os.path.dirname(__file__), 'assets',
                                   'molecular_nodes_append_file.blend') +
            r'\NodeTree',
            filename=new_node,
            link=False)
    else:
        pass
    new_node = new_node
    # Get the currently active GN tree
    obj = bpy.context.active_object
    node_tree = obj.modifiers.active
    new_node = new_node
    # Add the new node group, will have been appended to the scene previously by the 'load_node' function
    bpy.ops.node.add_node(type="GeometryNodeGroup",
                          use_transform=True,
                          settings=[{
                              "name":
                              "node_tree",
                              "value":
                              "bpy.data.node_groups['" + new_node + "']"
                          }])
    # select the just-added node, and make it currently being transformed by the user
    node = bpy.context.selected_nodes[0]
    bpy.ops.transform.translate('INVOKE_DEFAULT')


class SNA_MT_43F2D(bpy.types.Menu):
    bl_idname = "SNA_MT_43F2D"
    bl_label = ""

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw(self, context):
        layout = self.layout.column_flow(columns=1)
        op = layout.operator('sna.add_test_node_30300',
                             text='Add New Node',
                             icon_value=0,
                             emboss=True,
                             depress=False)
        op = layout.operator('sna.add_another_node_1163f',
                             text='another_node',
                             icon_value=0,
                             emboss=True,
                             depress=False)


class SNA_PT_MOLECULAR_NODES_1876B(bpy.types.Panel):
    bl_label = 'Molecular Nodes'
    bl_idname = 'SNA_PT_MOLECULAR_NODES_1876B'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'Molecular Nodes'
    bl_order = 0

    bl_ui_units_x = 0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        layout.label(text='Download from the PDB', icon_value=0)
        box_008BF = layout.box()
        box_008BF.alert = False
        box_008BF.enabled = True
        box_008BF.use_property_split = False
        box_008BF.use_property_decorate = False
        box_008BF.alignment = 'Expand'.upper()
        box_008BF.scale_x = 1.0
        box_008BF.scale_y = 1.2999999523162842
        row_ABB7D = box_008BF.row(heading='', align=False)
        row_ABB7D.alert = False
        row_ABB7D.enabled = True
        row_ABB7D.use_property_split = False
        row_ABB7D.use_property_decorate = False
        row_ABB7D.scale_x = 2.9679999351501465
        row_ABB7D.scale_y = 1.0
        row_ABB7D.alignment = 'Expand'.upper()
        row_ABB7D.prop(bpy.context.scene,
                       'sna_pdb_code',
                       text='PDB',
                       icon_value=0,
                       emboss=True)
        op = row_ABB7D.operator('sna.import_protein_fetch_pdb_4cf80',
                                text='Open',
                                icon_value=169,
                                emboss=True,
                                depress=False)
        layout.separator(factor=1.0)
        layout.label(text='Open Local File', icon_value=0)
        box_00078 = layout.box()
        box_00078.alert = False
        box_00078.enabled = True
        box_00078.use_property_split = False
        box_00078.use_property_decorate = False
        box_00078.alignment = 'Expand'.upper()
        box_00078.scale_x = 1.0
        box_00078.scale_y = 1.2999999523162842
        row_3131A = box_00078.row(heading='', align=False)
        row_3131A.alert = False
        row_3131A.enabled = True
        row_3131A.use_property_split = False
        row_3131A.use_property_decorate = False
        row_3131A.scale_x = 1.0
        row_3131A.scale_y = 1.0
        row_3131A.alignment = 'Expand'.upper()
        row_3131A.prop(bpy.context.scene,
                       'sna_molecule_name',
                       text='Name',
                       icon_value=0,
                       emboss=True)
        op = row_3131A.operator('sna.import_protein_local_ecb16',
                                text='Open',
                                icon_value=169,
                                emboss=True,
                                depress=False)
        box_00078.label(text='Files supported: *.pdb, *.mmtf, *.cif, *.gz',
                        icon_value=0)
        box_00078.prop(bpy.context.scene,
                       'sna_pdb_path',
                       text='PDB File',
                       icon_value=0,
                       emboss=True)
        layout.separator(factor=1.0)
        layout.label(text='Adjust Structure Size', icon_value=0)
        box_60F24 = layout.box()
        box_60F24.alert = False
        box_60F24.enabled = True
        box_60F24.use_property_split = False
        box_60F24.use_property_decorate = False
        box_60F24.alignment = 'Expand'.upper()
        box_60F24.scale_x = 1.0
        box_60F24.scale_y = 1.2999999523162842
        box_60F24.label(text='1 nm will be rescaled to this size.',
                        icon_value=0)
        box_60F24.prop(bpy.context.scene,
                       'sna_nanometre_scale',
                       text='Nanometre Scale',
                       icon_value=0,
                       emboss=True)


class SNA_AddonPreferences_9D182(bpy.types.AddonPreferences):
    bl_idname = 'molecular_nodes'

    def draw(self, context):
        if not (False):
            layout = self.layout
            layout.label(
                text=
                'To install on Windows, you must start Blender as Administrator.',
                icon_value=2)
            layout.label(
                text=
                'Wait several seconds for it to download and install. This step should only be required to run once.',
                icon_value=0)
            op = layout.operator('sna.install_atomium_bd760',
                                 text='Install Atomium',
                                 icon_value=746,
                                 emboss=True,
                                 depress=False)


class SNA_OT_Install_Atomium_Bd760(bpy.types.Operator):
    bl_idname = "sna.install_atomium_bd760"
    bl_label = "install_atomium"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        #For Blender 2.92:
        #You have to have admininistor priviledges so for Windows users
        #JUST THIS ONCE open Blender by R-clicking on it in the start menu and select"Run as Administrator"
        #Open up the System Console (under the Window menu)
        #Then paste and run the following into the scripting workspace and run it
        # After it has run, then close and reopen Blender normally
        # You can then then use the module as normal with
        # import MODULE
        #--- FROM HERE ---#
        import sys

        # path to python.exe
        python_exe = os.path.realpath(sys.executable)

        # upgrade pip
        subprocess.call([python_exe, "-m", "ensurepip"])
        subprocess.call(
            [python_exe, "-m", "pip", "install", "--upgrade", "pip"])

        # install required packages
        subprocess.call([python_exe, "-m", "pip", "install", "atomium"])
        print("Atomium Successfully Installed")
        #def install(package):
        #    subprocess.check_call([sys.executable, "-m", "pip", "install", package])
        #install("atomium")
        self.report({'INFO'}, message='Successfully installed Atomium.')
        return {"FINISHED"}

    def invoke(self, context, event):

        return self.execute(context)


def register():

    global _icons
    _icons = bpy.utils.previews.new()
    bpy.types.Scene.sna_pdb_code = bpy.props.StringProperty(
        name='pdb_code',
        description='The PDB ID of the structre you would like to download.',
        default='1bna',
        subtype='NONE',
        maxlen=0)
    bpy.types.Scene.sna_nanometre_scale = bpy.props.FloatProperty(
        name='nanometre_scale',
        description=
        'Scale the model so that one angstrom is this size in metres.',
        default=1.0,
        subtype='NONE',
        unit='LENGTH',
        step=3,
        precision=3)
    bpy.types.Scene.sna_pdb_path = bpy.props.StringProperty(
        name='pdb_path',
        description='File path to .pdb file.',
        default='',
        subtype='FILE_PATH',
        maxlen=0)
    bpy.types.Scene.sna_molecule_name = bpy.props.StringProperty(
        name='molecule_name',
        description='',
        default='',
        subtype='NONE',
        maxlen=0)

    bpy.utils.register_class(SNA_OT_Import_Protein_Fetch_Pdb_4Cf80)
    bpy.utils.register_class(SNA_OT_Import_Protein_Local_Ecb16)
    bpy.types.NODE_MT_add.prepend(sna_add_to_node_mt_add_284D4)
    bpy.utils.register_class(SNA_OT_Add_Test_Node_30300)
    bpy.utils.register_class(SNA_OT_Add_Another_Node_1163F)
    bpy.utils.register_class(SNA_MT_F5083)
    bpy.utils.register_class(SNA_MT_43F2D)
    bpy.utils.register_class(SNA_PT_MOLECULAR_NODES_1876B)
    bpy.utils.register_class(SNA_AddonPreferences_9D182)
    bpy.utils.register_class(SNA_OT_Install_Atomium_Bd760)


def unregister():

    global _icons
    bpy.utils.previews.remove(_icons)

    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    for km, kmi in addon_keymaps.values():
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    del bpy.types.Scene.sna_molecule_name
    del bpy.types.Scene.sna_pdb_path
    del bpy.types.Scene.sna_nanometre_scale
    del bpy.types.Scene.sna_pdb_code

    bpy.utils.unregister_class(SNA_OT_Import_Protein_Fetch_Pdb_4Cf80)
    bpy.utils.unregister_class(SNA_OT_Import_Protein_Local_Ecb16)
    bpy.types.NODE_MT_add.remove(sna_add_to_node_mt_add_284D4)
    bpy.utils.unregister_class(SNA_OT_Add_Test_Node_30300)
    bpy.utils.unregister_class(SNA_OT_Add_Another_Node_1163F)
    bpy.utils.unregister_class(SNA_MT_F5083)
    bpy.utils.unregister_class(SNA_MT_43F2D)
    bpy.utils.unregister_class(SNA_PT_MOLECULAR_NODES_1876B)
    bpy.utils.unregister_class(SNA_AddonPreferences_9D182)
    bpy.utils.unregister_class(SNA_OT_Install_Atomium_Bd760)
