bl_info = {
    "name" : "Molecular Nodes",
    "author" : "Brady Johnston", 
    "description" : "A plugin and nodes for working with molecular data in Blender.",
    "blender" : (3, 1, 0),
    "version" : (0, 5, 22),
    "location" : "Perth, Australia",
    "waring" : "",
    "doc_url": "https://bradyajohnston.github.io/MolecularNodes/", 
    "tracker_url": "https://github.com/BradyAJohnston/MolecularNodes/issues", 
    "category" : "Molecular" 
}

import bpy
import bpy.utils.previews

import subprocess
import os
import sys
import site
import bpy
import re
import os
import os
import os
import os
import bpy
from gc import collect
import os
from time import time


def string_to_int(value):
    if value.isdigit():
        return int(value)
    return 0


def string_to_icon(value):
    if value in bpy.types.UILayout.bl_rna.functions["prop"].parameters[
            "icon"].enum_items.keys():
        return bpy.types.UILayout.bl_rna.functions["prop"].parameters[
            "icon"].enum_items[value].value
    return string_to_int(value)


def icon_to_string(value):
    for icon in bpy.types.UILayout.bl_rna.functions["prop"].parameters[
            "icon"].enum_items:
        if icon.value == value:
            return icon.name
    return "NONE"


def enum_set_to_string(value):
    if type(value) == set:
        if len(value) > 0:
            return "[" + (", ").join(list(value)) + "]"
        return "[]"
    return value


def string_to_type(value, to_type, default):
    try:
        value = to_type(value)
    except:
        value = default
    return value


addon_keymaps = {}
_icons = None
serpens_node_tree_1 = {
    'sna_new_variable': None,
}


def property_exists(prop_path):
    try:
        eval(prop_path)
        return True
    except:
        return False


class SNA_MT_43F2D(bpy.types.Menu):
    bl_idname = "SNA_MT_43F2D"
    bl_label = ""

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw(self, context):
        layout = self.layout.column_flow(columns=1)
        layout_function = layout
        sna_append_node_interface_92BEE(layout_function, 'Atomic Properties',
                                        'MOL_atomic_properties', 0)
        layout_function = layout
        sna_append_node_interface_92BEE(layout_function, 'Scale Radii',
                                        'MOL_scale_radii', 0)
        layout_function = layout
        sna_append_node_interface_92BEE(layout_function, 'Find Bonds',
                                        'MOL_find_bonds', 0)


def sna_add_to_node_mt_add_E78CC(self, context):
    if not (not 'GeometryNodeTree' == bpy.context.area.spaces[0].tree_type):
        layout = self.layout
        layout.menu('SNA_MT_F5083', text='Molecular Nodes', icon_value=88)


class SNA_OT_Install_Atomium_Bd760(bpy.types.Operator):
    bl_idname = "sna.install_atomium_bd760"
    bl_label = "install_atomium"
    bl_description = "Install and check for the atomium package"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        atomium_install_successful = None
        import sys
        import site
        # path to python.exe
        python_exe = os.path.realpath(sys.executable)
        # upgrade pip
        subprocess.call([python_exe, "-m", "ensurepip"])
        subprocess.call(
            [python_exe, "-m", "pip", "install", "--upgrade", "pip"],
            timeout=600)
        # install required packages
        subprocess.call([python_exe, "-m", "pip", "install", "atomium"],
                        timeout=600)

        def verify_user_sitepackages(package_location):
            if os.path.exists(
                    package_location) and package_location not in sys.path:
                sys.path.append(package_location)

        verify_user_sitepackages(site.getusersitepackages())
        try:
            import atomium
            atomium_install_successful = True
        except:
            atomium_install_successful = False
        bpy.context.preferences.addons[
            'molecular_nodes'].preferences.sna_pref_atomium_available = atomium_install_successful
        if atomium_install_successful:
            self.report({'INFO'}, message='Successfully installed Atomium.')
        else:
            self.report({'ERROR'}, message='Atomium installation failed.')
        return {"FINISHED"}

    def invoke(self, context, event):

        return self.execute(context)


class SNA_AddonPreferences_9D182(bpy.types.AddonPreferences):
    bl_idname = 'molecular_nodes'

    sna_pref_mda_dir_location: bpy.props.StringProperty(
        name='pref_mda_dir_location',
        description='Directory of which contains the MDAnalysis folder',
        default='',
        subtype='DIR_PATH',
        maxlen=0)

    sna_pref_mda_available: bpy.props.BoolProperty(name='pref_mda_available',
                                                   description='',
                                                   default=False)

    sna_pref_atomium_available: bpy.props.BoolProperty(
        name='pref_atomium_available', description='', default=False)

    sna_pref_mda_viewport: bpy.props.BoolProperty(
        name='pref_mda_viewport',
        description='Display the Molecular Nodes panel also in the 3D viewport',
        default=False)

    def draw(self, context):
        if not (False):
            layout = self.layout
            if bpy.context.preferences.addons[
                    'molecular_nodes'].preferences.sna_pref_atomium_available:
                pass
            else:
                layout.label(
                    text=
                    'To install on Windows, start Blender as Administrator.',
                    icon_value=2)
            if bpy.context.preferences.addons[
                    'molecular_nodes'].preferences.sna_pref_atomium_available:
                pass
            else:
                layout.label(text='Install Atomium only required to run once.',
                             icon_value=0)
            row_9841B = layout.row(heading='', align=False)
            row_9841B.alert = not bpy.context.preferences.addons[
                'molecular_nodes'].preferences.sna_pref_atomium_available
            row_9841B.enabled = True
            row_9841B.use_property_split = False
            row_9841B.use_property_decorate = False
            row_9841B.scale_x = 1.0
            row_9841B.scale_y = 1.0
            row_9841B.alignment = 'Expand'.upper()
            if bpy.context.preferences.addons[
                    'molecular_nodes'].preferences.sna_pref_atomium_available:
                row_9841B.label(text='Atomium Package Installed', icon_value=0)
            else:
                row_9841B.label(text='Atomium Package', icon_value=0)
            if bpy.context.preferences.addons[
                    'molecular_nodes'].preferences.sna_pref_atomium_available:
                op = row_9841B.operator('sna.install_atomium_bd760',
                                        text='Upgrade Atomium',
                                        icon_value=746,
                                        emboss=True,
                                        depress=False)
            else:
                op = row_9841B.operator('sna.install_atomium_bd760',
                                        text='Install Atomium',
                                        icon_value=746,
                                        emboss=True,
                                        depress=False)
            layout.label(text='Path to MDAnalysis Installation', icon_value=0)
            layout.prop(
                bpy.context.preferences.addons['molecular_nodes'].preferences,
                'sna_pref_mda_dir_location',
                text='Package Directory',
                icon_value=0,
                emboss=True)
            row_08676 = layout.row(heading='', align=False)
            row_08676.alert = not bpy.context.preferences.addons[
                'molecular_nodes'].preferences.sna_pref_mda_available
            row_08676.enabled = True
            row_08676.use_property_split = False
            row_08676.use_property_decorate = False
            row_08676.scale_x = 1.0
            row_08676.scale_y = 1.0
            row_08676.alignment = 'Expand'.upper()
            if bpy.context.preferences.addons[
                    'molecular_nodes'].preferences.sna_pref_mda_available:
                row_08676.label(text='MDAnalysis Available', icon_value=0)
            else:
                row_08676.label(text='MDAnalaysis Unavailable', icon_value=0)
            if bpy.context.preferences.addons[
                    'molecular_nodes'].preferences.sna_pref_mda_available:
                op = row_08676.operator('sna.check_mda_install_66f5a',
                                        text='Re-Check Installation',
                                        icon_value=746,
                                        emboss=True,
                                        depress=False)
            else:
                op = row_08676.operator('sna.check_mda_install_66f5a',
                                        text='Check Installation',
                                        icon_value=746,
                                        emboss=True,
                                        depress=False)
            layout.label(
                text=
                'By default Molecular Nodes is available under the Scene Properties of the editor panel.',
                icon_value=156)
            layout.label(
                text='You can also enable the panel in the 3D viewport below.',
                icon_value=104)
            layout.prop(
                bpy.context.preferences.addons['molecular_nodes'].preferences,
                'sna_pref_mda_viewport',
                text='Enable Molecular Nodes in 3D Viewport',
                icon_value=0,
                emboss=True)


class SNA_OT_Check_Mda_Install_66F5A(bpy.types.Operator):
    bl_idname = "sna.check_mda_install_66f5a"
    bl_label = "check_mda_install"
    bl_description = "Check for an available installation of the MDAnalysis package"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        mda_dir_location = bpy.context.preferences.addons[
            'molecular_nodes'].preferences.sna_pref_mda_dir_location
        mda_available = None
        import os
        # path to python.exe
        python_exe = os.path.realpath(sys.executable)

        def verify_user_sitepackages(package_location):
            if os.path.exists(
                    package_location) and package_location not in sys.path:
                sys.path.append(package_location)

        verify_user_sitepackages(site.getusersitepackages())
        verify_user_sitepackages(mda_dir_location)
        try:
            import MDAnalysis as mda
            mda_available = True
        except:
            mda_available = False
        bpy.context.preferences.addons[
            'molecular_nodes'].preferences.sna_pref_mda_available = mda_available
        if mda_available:
            self.report({'INFO'}, message='MDAnalysis available.')
        else:
            self.report({'ERROR'}, message='MDAnalysis Unavaiable')
        return {"FINISHED"}

    def invoke(self, context, event):

        return self.execute(context)


class SNA_MT_1C944(bpy.types.Menu):
    bl_idname = "SNA_MT_1C944"
    bl_label = ""

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw(self, context):
        layout = self.layout.column_flow(columns=1)
        layout_function = layout
        sna_append_node_interface_92BEE(layout_function, 'Style Colour',
                                        'MOL_style_colour', 0)
        layout_function = layout
        sna_append_node_interface_92BEE(layout_function, 'Style Colour Manual',
                                        'MOL_style_manual_colour', 0)
        layout_function = layout
        sna_append_node_interface_92BEE(layout_function, 'Style Surface',
                                        'MOL_style_surface', 0)

        layout_function = layout
        sna_append_node_interface_92BEE(layout_function, 'Style Ribbon',
                                        'MOL_style_ribbon', 0)
        layout_function = layout
        sna_append_node_interface_92BEE(layout_function, 'Atoms EEVEE',
                                        'MOL_atoms_EEVEE', 0)
        layout_function = layout
        sna_append_node_interface_92BEE(layout_function, 'Map Range',
                                        'MOL_map_range', 0)


class SNA_MT_47239(bpy.types.Menu):
    bl_idname = "SNA_MT_47239"
    bl_label = ""

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw(self, context):
        layout = self.layout.column_flow(columns=1)
        layout_function = layout
        sna_append_node_interface_92BEE(layout_function, 'Pipes', 'MOL_pipes',
                                        0)
        layout_function = layout
        sna_append_node_interface_92BEE(layout_function, 'Backup Mesh',
                                        'MOL_utils_backup_mesh', 0)
        layout_function = layout
        sna_append_node_interface_92BEE(layout_function, 'Vertex',
                                        'MOL_vertex', 0)
        layout_function = layout
        sna_append_node_interface_92BEE(layout_function, 'Switch Float',
                                        'MOL_utils_switch_float', 0)
        layout_function = layout
        sna_append_node_interface_92BEE(layout_function, 'Pick Instance',
                                        'MOL_utils_pick_instance', 0)
        layout_function = layout
        sna_append_node_interface_92BEE(layout_function, 'Boolean Chain',
                                        'MOL_utils_bool_chain', 0)
        layout_function = layout
        sna_append_node_interface_92BEE(layout_function, 'Distance Probe',
                                        'MOL_utils_primitive_distance_probe',
                                        0)


def sna_func_interface_import_options_F89D1(layout_function, ):
    pass
    layout_function.label(text='Model Import Options', icon_value=442)
    row_A1800 = layout_function.row(heading='', align=False)
    row_A1800.alert = False
    row_A1800.enabled = True
    row_A1800.use_property_split = False
    row_A1800.use_property_decorate = False
    row_A1800.scale_x = 1.0
    row_A1800.scale_y = 1.0
    row_A1800.alignment = 'Expand'.upper()
    row_A1800.prop(bpy.context.scene,
                   'sna_create_bonds',
                   text='  Calculate Bonds ',
                   icon_value=0,
                   emboss=True,
                   invert_checkbox=False)
    row_A1800.prop(bpy.context.scene,
                   'sna_connect_cutoff',
                   text='Cutoff',
                   icon_value=0,
                   emboss=True)
    row_6617D = layout_function.row(heading='', align=False)
    row_6617D.alert = False
    row_6617D.enabled = True
    row_6617D.use_property_split = False
    row_6617D.use_property_decorate = False
    row_6617D.scale_x = 1.0
    row_6617D.scale_y = 1.0
    row_6617D.alignment = 'Expand'.upper()
    row_6617D.prop(bpy.context.scene,
                   'sna_build_assembly',
                   text='  Build Biological Assembly',
                   icon_value=0,
                   emboss=True)
    row_6617D.prop(bpy.context.scene,
                   'sna_build_assembly_id',
                   text='Assembly',
                   icon_value=0,
                   emboss=True)
    row_709A5 = layout_function.row(heading='', align=False)
    row_709A5.alert = False
    row_709A5.enabled = True
    row_709A5.use_property_split = False
    row_709A5.use_property_decorate = False
    row_709A5.scale_x = 1.0
    row_709A5.scale_y = 1.0
    row_709A5.alignment = 'Expand'.upper()
    row_709A5.label(text='1 nm will be rescaled to this size.', icon_value=0)
    row_709A5.prop(bpy.context.scene,
                   'sna_nanometre_scale',
                   text='Nanometre Scale',
                   icon_value=0,
                   emboss=True)


def sna_panel_category_interface_632C8(layout_function, label, panel_display,
                                       input):
    pass
    op = layout_function.operator(
        'sna.panel_category_d9ef0',
        text=label,
        icon_value=input,
        emboss=True,
        depress=panel_display == bpy.context.scene.sna_interface_display)
    op.sna_panel_display = panel_display


class SNA_OT_Panel_Category_D9Ef0(bpy.types.Operator):
    bl_idname = "sna.panel_category_d9ef0"
    bl_label = "panel_category"
    bl_description = "Change workspace"
    bl_options = {"REGISTER", "UNDO"}

    sna_panel_display: bpy.props.IntProperty(name='panel_display',
                                             description='',
                                             default=0,
                                             subtype='NONE')

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        bpy.context.scene.sna_interface_display = self.sna_panel_display
        return {"FINISHED"}

    def invoke(self, context, event):

        return self.execute(context)


class SNA_OT_Import_Method_6D000(bpy.types.Operator):
    bl_idname = "sna.import_method_6d000"
    bl_label = "import_method"
    bl_description = "Change import method"
    bl_options = {"REGISTER", "UNDO"}

    sna_interface_value: bpy.props.IntProperty(name='interface_value',
                                               description='',
                                               default=0,
                                               subtype='NONE')

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        bpy.context.scene.sna_load_struc_mod_traj = self.sna_interface_value
        return {"FINISHED"}

    def invoke(self, context, event):

        return self.execute(context)


def sna_interface_import_method_02671(layout_function, label, interface_value,
                                      icon):
    pass
    op = layout_function.operator(
        'sna.import_method_6d000',
        text=label,
        icon_value=icon,
        emboss=True,
        depress=interface_value == bpy.context.scene.sna_load_struc_mod_traj)
    op.sna_interface_value = interface_value


def sna_func_import_structure_EE5B6(pdb_code, nanometre_scale, fetch_pdb,
                                    pdb_path, molecule_name, create_bonds,
                                    connect_cutoff, build_assembly,
                                    build_assembly_id):
    pdb_code = pdb_code
    nanometre_scale = nanometre_scale
    fetch_pdb = fetch_pdb
    pdb_path = pdb_path
    molecule_name = molecule_name
    create_bonds = create_bonds
    connect_cutoff = connect_cutoff
    build_assembly = build_assembly
    build_assembly_id = build_assembly_id
    output_name = None
    unique_chains = None
    base_model = None
    col_properties = None
    col_frames = None
    import numpy as np
    import sys
    import site

    def verify_user_sitepackages():
        usersitepackagespath = site.getusersitepackages()
        if os.path.exists(
                usersitepackagespath) and usersitepackagespath not in sys.path:
            sys.path.append(usersitepackagespath)

    verify_user_sitepackages()
    try:
        import atomium
    except:
        print("Atomium Not Installed")
    atom_name_dict = {
        'C': 1,
        "C1'": 2,
        'C2': 3,
        "C2'": 4,
        "C3'": 5,
        'C4': 6,
        "C4'": 7,
        'C5': 8,
        "C5'": 9,
        'C6': 10,
        'C7': 11,
        'C8': 12,
        'CA': 13,
        'CB': 14,
        'CD': 15,
        'CD1': 16,
        'CD2': 17,
        'CE': 18,
        'CE1': 19,
        'CE2': 20,
        'CG': 21,
        'CG1': 22,
        'CG2': 23,
        'CZ': 24,
        'N': 25,
        'N1': 26,
        'N2': 27,
        'N3': 28,
        'N4': 29,
        'NZ': 30,
        'O': 31,
        'O2': 32,
        "O3'": 33,
        'O4': 34,
        "O4'": 35,
        "O5'": 36,
        'O6': 37,
        'OD1': 38,
        'OD2': 39,
        'OE1': 40,
        'OE2': 41,
        'OG': 42,
        'OG1': 43,
        'OH': 44,
        'OP1': 45,
        'OP2': 46,
        'OXT': 47,
        'P': 48,
        'SD': 49,
        'SG': 50
    }
    element_dict = {
        "H": {
            "atomic_number": 1,
            "radii": 1.10
        },
        "He": {
            "atomic_number": 2,
            "radii": 1.40
        },
        "Li": {
            "atomic_number": 3,
            "radii": 1.82
        },
        "Be": {
            "atomic_number": 4,
            "radii": 1.53
        },
        "B": {
            "atomic_number": 5,
            "radii": 1.92
        },
        "C": {
            "atomic_number": 6,
            "radii": 1.70
        },
        "N": {
            "atomic_number": 7,
            "radii": 1.55
        },
        "O": {
            "atomic_number": 8,
            "radii": 1.52
        },
        "F": {
            "atomic_number": 9,
            "radii": 1.47
        },
        "Ne": {
            "atomic_number": 10,
            "radii": 1.54
        },
        "Na": {
            "atomic_number": 11,
            "radii": 2.27
        },
        "Mg": {
            "atomic_number": 12,
            "radii": 1.73
        },
        "Al": {
            "atomic_number": 13,
            "radii": 1.84
        },
        "Si": {
            "atomic_number": 14,
            "radii": 2.10
        },
        "P": {
            "atomic_number": 15,
            "radii": 1.80
        },
        "S": {
            "atomic_number": 16,
            "radii": 1.80
        },
        "Cl": {
            "atomic_number": 17,
            "radii": 1.75
        },
        "Ar": {
            "atomic_number": 18,
            "radii": 1.88
        },
        "K": {
            "atomic_number": 19,
            "radii": 2.75
        },
        "Ca": {
            "atomic_number": 20,
            "radii": 2.31
        }
    }
    radii_dict = {
        "H": 1.10,
        "He": 1.40,
        "Li": 1.82,
        "Be": 1.53,
        "B": 1.92,
        "C": 1.70,
        "N": 1.55,
        "O": 1.52,
        "F": 1.47,
        "Ne": 1.54,
        "Na": 2.27,
        "Mg": 1.73,
        "Al": 1.84,
        "Si": 2.10,
        "P": 1.80,
        "S": 1.80,
        "Cl": 1.75,
        "Ar": 1.88,
        "K": 2.75,
        "Ca": 2.31,
        "Sc": 2.11,
        # break in the elements, no longer in direct numerical order
        "Ni": 1.63,
        "Cu": 1.40,
        "Zn": 1.39
    }
    AA_dict = {
        # 20 naturally occurring amino acids
        "ALA": {
            "aa_number": 1,
            "aa_type": "polar",
            "aa_type_no": 1
        },
        "ARG": {
            "aa_number": 2,
            "aa_type": "polar",
            "aa_type_no": 1
        },
        "ASN": {
            "aa_number": 3,
            "aa_type": "polar",
            "aa_type_no": 1
        },
        "ASP": {
            "aa_number": 4,
            "aa_type": "polar",
            "aa_type_no": 1
        },
        "CYS": {
            "aa_number": 5,
            "aa_type": "polar",
            "aa_type_no": 1
        },
        "GLU": {
            "aa_number": 6,
            "aa_type": "polar",
            "aa_type_no": 1
        },
        "GLN": {
            "aa_number": 7,
            "aa_type": "polar",
            "aa_type_no": 1
        },
        "GLY": {
            "aa_number": 8,
            "aa_type": "polar",
            "aa_type_no": 1
        },
        "HIS": {
            "aa_number": 9,
            "aa_type": "polar",
            "aa_type_no": 1
        },
        "ILE": {
            "aa_number": 10,
            "aa_type": "polar",
            "aa_type_no": 1
        },
        "LEU": {
            "aa_number": 11,
            "aa_type": "polar",
            "aa_type_no": 1
        },
        "LYS": {
            "aa_number": 12,
            "aa_type": "polar",
            "aa_type_no": 1
        },
        "MET": {
            "aa_number": 13,
            "aa_type": "polar",
            "aa_type_no": 1
        },
        "PHE": {
            "aa_number": 14,
            "aa_type": "polar",
            "aa_type_no": 1
        },
        "PRO": {
            "aa_number": 15,
            "aa_type": "polar",
            "aa_type_no": 1
        },
        "SER": {
            "aa_number": 16,
            "aa_type": "polar",
            "aa_type_no": 1
        },
        "THR": {
            "aa_number": 17,
            "aa_type": "polar",
            "aa_type_no": 1
        },
        "TRP": {
            "aa_number": 18,
            "aa_type": "polar",
            "aa_type_no": 1
        },
        "TYR": {
            "aa_number": 19,
            "aa_type": "polar",
            "aa_type_no": 1
        },
        "VAL": {
            "aa_number": 20,
            "aa_type": "polar",
            "aa_type_no": 1
        },
        # unknown? Came up in one of the structures, haven't looked into it yet
        # TODO look into it!
        "UNK": {
            "aa_number": 21,
            "aa_type": "unkown",
            "aa_type_no": 1
        },
        # nucleic acids
        # DNA
        "DC": {
            "aa_number": 31,
            "aa_type": "unkown",
            "aa_type_no": 1
        },
        "DG": {
            "aa_number": 32,
            "aa_type": "unkown",
            "aa_type_no": 1
        },
        "DA": {
            "aa_number": 33,
            "aa_type": "unkown",
            "aa_type_no": 1
        },
        "DT": {
            "aa_number": 34,
            "aa_type": "unkown",
            "aa_type_no": 1
        },
        # RNA
        "C": {
            "aa_number": 41,
            "aa_type": "unkown",
            "aa_type_no": 1
        },
        "G": {
            "aa_number": 42,
            "aa_type": "unkown",
            "aa_type_no": 1
        },
        "A": {
            "aa_number": 43,
            "aa_type": "unkown",
            "aa_type_no": 1
        },
        "U": {
            "aa_number": 44,
            "aa_type": "unkown",
            "aa_type_no": 1
        }
    }
    ###
    # The following variables are passed in when the operators are called, and it is set up properly by Serpens when built
    # They are thusly not defined in the actual code, but are included here for reference
    ###
    # create_bonds = True
    # pdb_code = "4ozs"
    # namometre_scale = 1
    # pdb_path = "C:\\Users\\bradyjohnston\\Desktop\\4ozs.pdb"
    # connect_cutoff = 0.35
    # build_assembly = True
    # build_assembly_id = 1
    pdb_id = pdb_code
    one_nanometre_size_in_metres = nanometre_scale * 0.1
    # download the required model
    if (fetch_pdb):
        pdb = atomium.fetch(pdb_id)
        output_name = pdb_id
    else:
        pdb_id = molecule_name
        pdb = atomium.open(pdb_path)
        # set the molecule name for local import
        if molecule_name == "":
            molecule_name = "new_molecule"
        output_name = molecule_name
    pdb_backup = pdb
    # If true, the biological assembly will be built first and then imported.
    # This can likely be translated to a set of geometry nodes to reduce computation
    # time and also make it dynamic, but that will involve coding the creation of a bunch
    # of nodes which will be a nightmare. Colouring all of the atoms will be problematic as
    # well until the named attributes are properly released in blender 3.2, for now this
    # will be fine as viewport performance for the point clouds is very good. Will increase
    # the load times though depending on the assembly, as it will drastically increase the
    # number of atoms to iterate over.
    if build_assembly:
        # try to build the array with the given id, but if it fails (such as wrong id) continue on with the original mode.
        # TODO add a warning that will be displayed upon failure to build array.
        try:
            pdb = pdb.generate_assembly(build_assembly_id)
        except:
            print(
                Warning("Failed to generate biological assembly of id" +
                        str(build_assembly_id)))
    #pdb = atomium.open("C:\\Users\\BradyJohnston\\Desktop\\atp-frames.pdb")
    # check the number of models in the file
    if build_assembly:
        first_model = pdb
        n_models = 1
    else:
        first_model = pdb.models[0]
        n_models = len(pdb.models)
    n_atoms = len(first_model.atoms())
    all_chains = first_model.chains()
    # contains the atom number in the PDB file, acts as the index for everything.
    atom_id = []
    # contains the XYZ coordinates for the atom
    atom_location = []
    # contains the character sumbol of the element for the atom, i.e. 'H' for Hydrogen
    # and 'C' for Carbon
    atom_element_char = []
    # contains the atomic number of the number, has to be matched later against a
    # dictionary as the pip release of atomium doesn't currently have quick-access
    # to the atomic number, only the symbol
    atom_element_num = []
    # contains the name of the atom, which varies depending on where the atom appears
    # in the residue, C, C1' etc, with the second list being the numeric encoding of
    # this for use in geometry nodes
    atom_name_char = []
    atom_name_num = []
    # contains the letter code that is the representative of the chain that the
    # residue is part of, with the second list being the numeric encoding of this
    # for use in geometry nodes
    atom_chain_char = []
    atom_chain_num = []
    # contains the 3-letter codes that ID The AA side chain the atom is a part of,
    # or the single or two-letter codes for nucleic acids, with the second list
    # being the numeric encoding of this for use in geometry nodes
    atom_aa_id_char = []
    atom_aa_id_number = []
    # contains the integer representing the residue number in the sequence of the
    # protein that the atom is part of
    atom_aa_sequence_number = []
    # contains the b-factor for each atom, which is a representation of how
    # static the atom is when part of the overall structure
    atom_b_factor = []
    # contains TRUE / FALSE for whether the atom is part of the backbone
    atom_is_backbone = []
    # contains True / False for whether the atom is part of a sidechain
    atom_is_sidechain = []

    def try_lookup(dict, key, value_on_fail=0):
        """
        Try looking up the value from the key in the dictionary, 
        otherwise return the value on fail so that things can keep moving
        """
        try:
            return dict[key]
        except:
            return value_on_fail

    def try_append(list, value, value_on_fail=0):
        """
        Tries to append the value to the list, and adds instead the value on fail
        instead if a lookup into one of the dictionaries has failed.
        """
        try:
            list.append(value)
        except:
            list.append(value_on_fail)

    def element_from_atom_name(atom_name):
        return re.findall("^[A-Z][a-z]?", atom_name)[0]

    def get_element(atom):
        # try:
        #     element = atom.element
        # except:
        #     element = element_from_atom_name(atom.name)
        # if element == "X" or element == "" or element == None:
        element = element_from_atom_name(atom.name)
        return element

    def get_element_num(element):
        try:
            element_number = element_dict.get(element).get("atomic_number")
        except:
            element_number = 0
        return element_number

    def get_chain_char(atom):
        try:
            return atom.chain
        except:
            return "X"

    # def get_aa_sequence_number(atom):
    #     try:
    #         atom.
    for chain in first_model.chains():
        current_chain = chain.id
        for res in chain.residues():
            current_aa_id_char = res.name
            # the numbers at the end of the AA identifier "ASP.19" etc
            current_aa_sequence_number = int(
                re.findall(r"\d+",
                           res.id.split(".")[1])[0])
            for atom in res.atoms():
                try_append(atom_id, atom.id)
                try_append(atom_location, atom.location)
                try_append(atom_element_char, get_element(atom))
                try_append(atom_element_num,
                           get_element_num(get_element(atom)))
                try_append(atom_name_char, atom.name)
                try_append(atom_chain_char, current_chain)
                try_append(atom_aa_sequence_number, current_aa_sequence_number)
                try_append(atom_aa_id_char, current_aa_id_char)
                try_append(
                    atom_aa_id_number,
                    try_lookup(try_lookup(AA_dict, current_aa_id_char),
                               "aa_number"))
                # try_append(atom_aa_id_number, AA_dict[current_aa_id_char]["aa_number"])
                try_append(atom_b_factor, atom.bvalue)
                try_append(atom_is_backbone, int(atom.is_backbone))
                try_append(atom_is_sidechain, int(atom.is_side_chain))
    # turn all of the lists into numpy arrays, so that they can be rearranged based
    # on the atom indices created with np.argsort()
    atom_id = np.array(atom_id)
    atom_location = np.array(atom_location)
    atom_element_char = np.array(atom_element_char)
    atom_element_num = np.array(atom_element_num)
    atom_name_char = np.array(atom_name_char)
    # atom_name_num = np.array(atom_name_num)
    atom_chain_char = np.array(atom_chain_char)
    # atom_chain_num = np.array(atom_chain_num)
    atom_aa_id_char = np.array(atom_aa_id_char)
    atom_aa_id_number = np.array(atom_aa_id_number)
    atom_aa_sequence_number = np.array(atom_aa_sequence_number)
    atom_b_factor = np.array(atom_b_factor)
    atom_is_backbone = np.array(atom_is_backbone)
    atom_is_sidechain = np.array(atom_is_sidechain)
    inds = atom_id.argsort()
    # rearrange all of the arrays based on the indices, so that all values
    # match properly, and the atoms are in ascending order
    atom_id = atom_id[inds]
    atom_location = atom_location[inds]
    atom_element_char = atom_element_char[inds]
    atom_element_num = atom_element_num[inds]
    atom_name_char = atom_name_char[inds]
    # atom_name_num = atom_name_num[inds]
    atom_chain_char = atom_chain_char[inds]
    # atom_chain_num = atom_chain_num[inds]
    atom_aa_id_char = atom_aa_id_char[inds]
    atom_aa_id_number = atom_aa_id_number[inds]
    atom_aa_sequence_number = atom_aa_sequence_number[inds]
    atom_b_factor = atom_b_factor[inds]
    atom_is_backbone = atom_is_backbone[inds]
    atom_is_sidechain = atom_is_sidechain[inds]
    unique_chains = np.array(list(set(atom_chain_char)))
    chain_inds = unique_chains.argsort()
    unique_chains = unique_chains[chain_inds]
    atom_chain_num = list(
        map(lambda x: int(np.where(x == unique_chains)[0]), atom_chain_char))
    atom_chain_num = np.array(atom_chain_num)
    unique_atoms = np.array(list(set(atom_name_char)))
    unique_atoms_inds = unique_atoms.argsort()
    unique_atoms = unique_atoms[unique_atoms_inds]
    atom_name_num = list(
        map(lambda x: int(try_lookup(atom_name_dict, x)), atom_name_char))
    atom_name_num = np.array(atom_name_num)

    def create_model(name, collection, locations, bonds=[], faces=[]):
        """
        Creates a mesh with the given name in the given collection, from the supplied
        values for the locationso of vertices, and if supplied, bonds and faces.
        """
        # create a new mesh
        atom_mesh = bpy.data.meshes.new(name)
        atom_mesh.from_pydata(locations, bonds, faces)
        new_object = bpy.data.objects.new(name, atom_mesh)
        collection.objects.link(new_object)
        return new_object

    # def lists_to_vec3_list(xvalue, yvalue, zvalue):
    #     list_of_vectors = list(map(
    #             lambda x: [xvalue[x], yvalue[x], zvalue[x]], range(len())
    #         )
    #     )
    def create_properties_model(name, collection, prop_x, prop_y, prop_z):
        """
        Creates a mesh that will act as a look up table for properties about the atoms
        in the actual mesh that will be created.
        """

        def get_value(vec, x):
            try:
                return vec[x]
            except:
                return 0

        create_model(name=name,
                     collection=collection,
                     locations=list(
                         map(
                             lambda x: [
                                 get_value(prop_x, x),
                                 get_value(prop_y, x),
                                 get_value(prop_z, x)
                             ], range(len(first_model.atoms())))))

    def get_bond_list(model, connect_cutoff=0.35, search_distance=2):
        """
        For all atoms in the model, search for the nearby atoms given the current 
        distance cutoff, then calculate whether or not they will be bonded to their 
        nearby atoms.
        Returns a list of lists, each with two integers in them, specifying the 
        indices of the two atoms that are to be bonded.
        """
        mod = model
        mod.optimise_distances()
        for chain in mod.chains():
            for atom in chain.atoms():
                primary_radius = radii_dict[atom.element]
                nearby_atoms = atom.nearby_atoms(search_distance)
                if atom.element == "H":
                    connect_adjust = -0.2
                else:
                    connect_adjust = 0
                for atom2 in nearby_atoms:
                    same_chain = (atom.chain.name == atom2.chain.name)
                    disulfide = ((atom.name == atom2.name)
                                 and (atom.name == 'SG'))
                    if not same_chain and not disulfide:
                        continue
                    # if both atoms are the sulfurs in cysteins, then treat as a
                    # disulfide bond which can be bonded from a longer distance
                    if disulfide:
                        connect_adjust == 0.2

                    secondary_radius = radii_dict[atom2.element]
                    distance = atom.distance_to(atom2)
                    if distance <= ((connect_cutoff + connect_adjust) +
                                    (primary_radius + secondary_radius) / 2):
                        atom.bond(atom2)
        all_atoms = mod.atoms()
        all_ids = np.array(list(map(lambda x: x.id, all_atoms)))
        inds = all_ids.argsort()
        all_ids = all_ids[inds]
        bond_list = []
        for atom in all_atoms:
            for atom2 in atom.bonded_atoms:
                bond_list.append([
                    int(np.where(atom.id == all_ids)[0]),
                    int(np.where(atom2.id == all_ids)[0])
                ])
        return bond_list

    def get_frame_positions(frame):
        """
        Returns a numpy array of all of the atom locations from the given frame. 
        Importantly it orders them according to their atom numbering to sync the frames.
        """
        all_atoms = frame.atoms()
        atom_id = list(map(lambda x: x.id, all_atoms))
        atom_location = list(map(lambda x: x.location, all_atoms))
        atom_id = np.array(atom_id)
        inds = atom_id.argsort()
        atom_id = atom_id[inds]
        atom_location = np.array(atom_location)
        atom_location = atom_location[inds]
        return atom_location

    def get_frame_bvalue(frame):
        """
        Returns a numpy array of all of the atom bvalue from the given frame. 
        Importantly it orders them according to their atom numbering to sync the frames.
        """
        all_atoms = frame.atoms()
        atom_id = list(map(lambda x: x.id, all_atoms))
        atom_bvalue = list(map(lambda x: x.bvalue, all_atoms))
        atom_id = np.array(atom_id)
        inds = atom_id.argsort()
        atom_id = atom_id[inds]
        atom_bvalue = np.array(atom_bvalue)
        atom_bvalue = atom_bvalue[inds]
        return atom_bvalue

    def get_model_element_number(model):
        """
        Returns a numpy array of all of the atom bvalue from the given frame. 
        Importantly it orders them according to their atom numbering to sync the frames.
        """

        def try_element_number(element):
            try:
                return element_dict[element]["atomic_number"]
            except:
                return 3

        all_atoms = model.atoms()
        atom_id = list(map(lambda x: x.id, all_atoms))
        atom_element = list(map(lambda x: get_element(x), all_atoms))
        atom_element_number = list(
            map(lambda x: try_element_number(x), atom_element))
        atom_id = np.array(atom_id)
        inds = atom_id.argsort()
        atom_id = atom_id[inds]
        atom_element_number = np.array(atom_element_number)
        atom_element_number = atom_element_number[inds]
        return atom_element_number

    def get_model_is_sidechain(model):
        """
        Returns a numpy array of all of the atom bvalue from the given frame. 
        Importantly it orders them according to their atom numbering to sync the frames.
        """

        def try_is_sidechain(atom):
            try:
                return int(atom.is_side_chain)
            except:
                return 0

        all_atoms = model.atoms()
        atom_id = list(map(lambda x: x.id, all_atoms))
        atom_is_sidechain = list(map(lambda x: try_is_sidechain(x), all_atoms))
        atom_id = np.array(atom_id)
        inds = atom_id.argsort()
        atom_id = atom_id[inds]
        atom_is_sidechain = np.array(atom_is_sidechain)
        atom_is_sidechain = atom_is_sidechain[inds]
        return atom_is_sidechain

    def get_model_is_backbone(model):
        """
        Returns a numpy array of all of the atom bvalue from the given frame. 
        Importantly it orders them according to their atom numbering to sync the frames.
        """

        def try_is_backbone(atom):
            try:
                return int(atom.is_backbone)
            except:
                return 0

        all_atoms = model.atoms()
        atom_id = list(map(lambda x: x.id, all_atoms))
        atom_is_backbone = list(map(lambda x: try_is_backbone(x), all_atoms))
        atom_id = np.array(atom_id)
        inds = atom_id.argsort()
        atom_id = atom_id[inds]
        atom_is_backbone = np.array(atom_is_backbone)
        atom_is_backbone = atom_is_backbone[inds]
        return atom_is_backbone

    def get_model_is_ca(model):
        """
        Returns numpy array of True / False if atom name is equal to CA.
        """
        all_atoms = model.atoms()
        try:
            atom_id = list(map(lambda x: x.id, all_atoms))
            atom_is_CA = list(map(lambda x: x.name == "CA", all_atoms))
            atom_id = np.array(atom_id)
            inds = atom_id.argsort()
            atom_is_CA = np.array(atom_is_CA)[inds]

        except:
            atom_is_CA = []
            for i in len(all_atoms):
                atom_is_CA.append(False)
        return atom_is_CA

    # See if there is a collection called "Molecular Nodes", if so, set it to be the parent
    # collection, otherwise create one and link it to the scene collection.
    try:
        parent_coll = bpy.data.collections['MolecularNodes']
        parent_coll.name == "MolecularNodes"
        # make the collection active, for creating and disabling new
        bpy.context.view_layer.active_layer_collection = bpy.context.view_layer.layer_collection.children[
            'MolecularNodes']
    except:
        parent_coll = bpy.data.collections.new('MolecularNodes')
        bpy.context.scene.collection.children.link(parent_coll)
        # make the collection active, for creating and disabling new
        bpy.context.view_layer.active_layer_collection = bpy.context.view_layer.layer_collection.children[
            'MolecularNodes']
    # create new collection that will house the data, link it to the parent collection
    col = bpy.data.collections.new(output_name)
    parent_coll.children.link(col)
    col_properties = bpy.data.collections.new(output_name + "_properties")
    col.children.link(col_properties)
    # If create_bonds selected, generate a list of vertex pairs that will be the bonds for the atomic mesh,
    # else return an empty list that will make no edges when passed to create_model()
    if create_bonds:
        bonds = get_bond_list(first_model, connect_cutoff=connect_cutoff)
    else:
        bonds = []
    # create the first model, that will be the actual atomic model the user will interact with and display
    base_model = create_model(name=output_name,
                              collection=col,
                              locations=get_frame_positions(first_model) *
                              one_nanometre_size_in_metres,
                              bonds=bonds)
    # Creat the different models that will encode the various properties into
    # the XYZ locations of ther vertices.
    create_properties_model(
        name=output_name + "_properties_1",
        collection=col_properties,
        prop_x=get_model_element_number(first_model),
        prop_y=atom_chain_num + 1,  # to have the first chain be indexed from 1
        prop_z=atom_name_num)
    create_properties_model(name=output_name + "_properties_2",
                            collection=col_properties,
                            prop_x=atom_aa_sequence_number,
                            prop_y=atom_id,
                            prop_z=atom_aa_id_number)
    create_properties_model(name=output_name + "_properties_3",
                            collection=col_properties,
                            prop_x=get_frame_bvalue(first_model),
                            prop_y=get_model_is_backbone(first_model),
                            prop_z=get_model_is_ca(first_model))
    # hide the created properties collection
    bpy.context.layer_collection.children[col.name].children[
        col_properties.name].exclude = True
    # create the frames
    if (n_models > 1):
        col_frames = bpy.data.collections.new(output_name + "_frames")
        col.children.link(col_frames)
        # for each model in the pdb, create a new object and add it to the frames collection
        # testing out the addition of points that represent the bfactors. You can then in theory
        # use the modulo of the index to be able to pick either the position or the bvalue for
        # each frame in the frames collection.
        for frame in pdb_backup.models:
            atom_locations = get_frame_positions(
                frame) * one_nanometre_size_in_metres
            # need to make sure that is a list of 3-element vectors to encode to the XYZ positions
            # of the vertices
            atom_bvalue = list(
                map(lambda x: [x, 0, 0], get_frame_bvalue(frame)))
            model_locations = list(atom_locations) + atom_bvalue
            create_model(name="frame_" + output_name,
                         collection=col_frames,
                         locations=model_locations)
        # hide the created frames collection
        bpy.context.layer_collection.children[col.name].children[
            col_frames.name].exclude = True
    sna_setup_node_tree_272D6(output_name, unique_chains, base_model,
                              col_properties, col_frames)


class SNA_PT_MOLECULAR_NODES_82594(bpy.types.Panel):
    bl_label = 'Molecular Nodes'
    bl_idname = 'SNA_PT_MOLECULAR_NODES_82594'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'Molecular Nodes'
    bl_order = 0
    bl_options = {'HEADER_LAYOUT_EXPAND'}

    bl_ui_units_x = 0

    @classmethod
    def poll(cls, context):
        return not (not bpy.context.preferences.addons['molecular_nodes'].
                    preferences.sna_pref_mda_viewport)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        layout_function = layout
        sna_function_interface_D4A42(layout_function, )


class SNA_PT_MOLECULAR_NODES_7D87B(bpy.types.Panel):
    bl_label = 'Molecular Nodes'
    bl_idname = 'SNA_PT_MOLECULAR_NODES_7D87B'
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_context = 'scene'

    bl_order = 0
    bl_options = {'HEADER_LAYOUT_EXPAND'}

    bl_ui_units_x = 0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        layout_function = layout
        sna_function_interface_D4A42(layout_function, )


def sna_function_interface_D4A42(layout_function, ):
    pass
    col_5D8FA = layout_function.column(heading='', align=False)
    col_5D8FA.alert = False
    col_5D8FA.enabled = True
    col_5D8FA.use_property_split = False
    col_5D8FA.use_property_decorate = False
    col_5D8FA.scale_x = 1.0
    col_5D8FA.scale_y = 1.0
    col_5D8FA.alignment = 'Expand'.upper()
    row_BD5B1 = col_5D8FA.row(heading='Workspace ', align=False)
    row_BD5B1.alert = False
    row_BD5B1.enabled = True
    row_BD5B1.use_property_split = False
    row_BD5B1.use_property_decorate = False
    row_BD5B1.scale_x = 1.0
    row_BD5B1.scale_y = 1.0
    row_BD5B1.alignment = 'Expand'.upper()
    row_BD5B1.menu('SNA_MT_68580',
                   text=['Import Structure', 'DNA Nodes',
                         'DNA Nodes'][bpy.context.scene.sna_interface_display],
                   icon_value=[169,
                               206][bpy.context.scene.sna_interface_display])
    if bpy.context.scene.sna_interface_display == 0:
        box_6248E = col_5D8FA.box()
        box_6248E.alert = False
        box_6248E.enabled = True
        box_6248E.use_property_split = False
        box_6248E.use_property_decorate = False
        box_6248E.alignment = 'Left'.upper()
        box_6248E.scale_x = 1.0
        box_6248E.scale_y = 1.0
        row_F31FD = box_6248E.row(heading='', align=True)
        row_F31FD.alert = False
        row_F31FD.enabled = True
        row_F31FD.use_property_split = False
        row_F31FD.use_property_decorate = False
        row_F31FD.scale_x = 1.0
        row_F31FD.scale_y = 1.2000000476837158
        row_F31FD.alignment = 'Expand'.upper()
        layout_function = row_F31FD
        sna_interface_import_method_02671(layout_function, 'PDB', 0, 72)
        layout_function = row_F31FD
        sna_interface_import_method_02671(layout_function, 'Local File', 1,
                                          108)
        layout_function = row_F31FD
        sna_interface_import_method_02671(layout_function, 'MD Trajectory', 2,
                                          487)
        if bpy.context.scene.sna_load_struc_mod_traj == 0:
            col_4257D = box_6248E.column(heading='', align=False)
            col_4257D.alert = not bpy.context.preferences.addons[
                'molecular_nodes'].preferences.sna_pref_atomium_available
            col_4257D.enabled = True
            col_4257D.use_property_split = False
            col_4257D.use_property_decorate = False
            col_4257D.scale_x = 1.0
            col_4257D.scale_y = 1.0
            col_4257D.alignment = 'Expand'.upper()
            if bpy.context.preferences.addons[
                    'molecular_nodes'].preferences.sna_pref_atomium_available:
                pass
            else:
                col_4257D.label(text='Atomium Not Installed', icon_value=3)
            box_768F1 = col_4257D.box()
            box_768F1.alert = False
            box_768F1.enabled = bpy.context.preferences.addons[
                'molecular_nodes'].preferences.sna_pref_atomium_available
            box_768F1.use_property_split = False
            box_768F1.use_property_decorate = False
            box_768F1.alignment = 'Expand'.upper()
            box_768F1.scale_x = 1.0
            box_768F1.scale_y = 1.0
            box_768F1.label(text='Download from the PDB', icon_value=72)
            row_ABB7D = box_768F1.row(heading='', align=False)
            row_ABB7D.alert = False
            row_ABB7D.enabled = True
            row_ABB7D.use_property_split = False
            row_ABB7D.use_property_decorate = False
            row_ABB7D.scale_x = 1.0
            row_ABB7D.scale_y = 1.2000000476837158
            row_ABB7D.alignment = 'Expand'.upper()
            row_ABB7D.prop(bpy.context.scene,
                           'sna_pdb_code',
                           text='PDB ID',
                           icon_value=0,
                           emboss=True)
            row_F763E = row_ABB7D.row(heading='', align=False)
            row_F763E.alert = False
            row_F763E.enabled = len(bpy.context.scene.sna_pdb_code) == 4
            row_F763E.use_property_split = False
            row_F763E.use_property_decorate = False
            row_F763E.scale_x = 1.0
            row_F763E.scale_y = 0.0
            row_F763E.alignment = 'Expand'.upper()
            op = row_F763E.operator('sna.import_protein_fetch_pdb_4cf80',
                                    text='Download',
                                    icon_value=169,
                                    emboss=True,
                                    depress=False)
            layout_function = box_768F1
            sna_func_interface_import_options_F89D1(layout_function, )
        else:
            if bpy.context.scene.sna_load_struc_mod_traj == 1:
                col_43211 = box_6248E.column(heading='', align=False)
                col_43211.alert = not bpy.context.preferences.addons[
                    'molecular_nodes'].preferences.sna_pref_atomium_available
                col_43211.enabled = True
                col_43211.use_property_split = False
                col_43211.use_property_decorate = False
                col_43211.scale_x = 1.0
                col_43211.scale_y = 1.0
                col_43211.alignment = 'Expand'.upper()
                if bpy.context.preferences.addons[
                        'molecular_nodes'].preferences.sna_pref_atomium_available:
                    pass
                else:
                    col_43211.label(text='Atomium Not Installed', icon_value=3)
                box_78D7E = col_43211.box()
                box_78D7E.alert = False
                box_78D7E.enabled = bpy.context.preferences.addons[
                    'molecular_nodes'].preferences.sna_pref_atomium_available
                box_78D7E.use_property_split = False
                box_78D7E.use_property_decorate = False
                box_78D7E.alignment = 'Left'.upper()
                box_78D7E.scale_x = 1.0
                box_78D7E.scale_y = 1.0
                box_78D7E.label(text='Open Local File', icon_value=44)
                row_BBC2B = box_78D7E.row(heading='', align=False)
                row_BBC2B.alert = False
                row_BBC2B.enabled = True
                row_BBC2B.use_property_split = False
                row_BBC2B.use_property_decorate = False
                row_BBC2B.scale_x = 1.0
                row_BBC2B.scale_y = 1.2000000476837158
                row_BBC2B.alignment = 'Expand'.upper()
                row_BBC2B.prop(bpy.context.scene,
                               'sna_molecule_name',
                               text='Name',
                               icon_value=0,
                               emboss=True)
                row_AFBA1 = row_BBC2B.row(heading='', align=False)
                row_AFBA1.alert = False
                row_AFBA1.enabled = os.path.exists(
                    bpy.context.scene.sna_pdb_path)
                row_AFBA1.use_property_split = False
                row_AFBA1.use_property_decorate = False
                row_AFBA1.scale_x = 1.0
                row_AFBA1.scale_y = 1.0
                row_AFBA1.alignment = 'Expand'.upper()
                op = row_AFBA1.operator('sna.import_protein_local_ecb16',
                                        text='Open',
                                        icon_value=169,
                                        emboss=True,
                                        depress=False)
                box_78D7E.label(
                    text='File formats supported: *.pdb, *.mmtf, *.cif, *.gz',
                    icon_value=634)
                box_78D7E.label(
                    text=
                    'Multi-model structures will be treated as trajectories.',
                    icon_value=0)
                row_86094 = box_78D7E.row(heading='', align=False)
                row_86094.alert = False
                row_86094.enabled = True
                row_86094.use_property_split = False
                row_86094.use_property_decorate = False
                row_86094.scale_x = 1.0
                row_86094.scale_y = 1.2000000476837158
                row_86094.alignment = 'Expand'.upper()
                row_86094.prop(bpy.context.scene,
                               'sna_pdb_path',
                               text='File Path',
                               icon_value=0,
                               emboss=True)
                layout_function = box_78D7E
                sna_func_interface_import_options_F89D1(layout_function, )
            else:
                if bpy.context.scene.sna_load_struc_mod_traj == 2:
                    col_58A9C = box_6248E.column(heading='', align=False)
                    col_58A9C.alert = not bpy.context.preferences.addons[
                        'molecular_nodes'].preferences.sna_pref_mda_available
                    col_58A9C.enabled = True
                    col_58A9C.use_property_split = False
                    col_58A9C.use_property_decorate = False
                    col_58A9C.scale_x = 1.0
                    col_58A9C.scale_y = 1.0
                    col_58A9C.alignment = 'Expand'.upper()
                    if not bpy.context.preferences.addons[
                            'molecular_nodes'].preferences.sna_pref_mda_available:
                        col_58A9C.label(text='MDAnalysis un-availlable',
                                        icon_value=3)
                    else:
                        pass
                    box_011E3 = col_58A9C.box()
                    box_011E3.alert = False
                    box_011E3.enabled = bpy.context.preferences.addons[
                        'molecular_nodes'].preferences.sna_pref_mda_available
                    box_011E3.use_property_split = False
                    box_011E3.use_property_decorate = False
                    box_011E3.alignment = 'Left'.upper()
                    box_011E3.scale_x = 1.0
                    box_011E3.scale_y = 1.0
                    box_011E3.label(text='Load MD Trajectory File',
                                    icon_value=348)
                    col_0E7C9 = box_011E3.column(heading='', align=False)
                    col_0E7C9.alert = True
                    col_0E7C9.enabled = True
                    col_0E7C9.use_property_split = False
                    col_0E7C9.use_property_decorate = False
                    col_0E7C9.scale_x = 1.0
                    col_0E7C9.scale_y = 1.0
                    col_0E7C9.alignment = 'Expand'.upper()
                    row_99A09 = col_0E7C9.row(heading='', align=False)
                    row_99A09.alert = False
                    row_99A09.enabled = True
                    row_99A09.use_property_split = False
                    row_99A09.use_property_decorate = False
                    row_99A09.scale_x = 1.0
                    row_99A09.scale_y = 1.2000000476837158
                    row_99A09.alignment = 'Expand'.upper()
                    row_99A09.prop(bpy.context.scene,
                                   'sna_molecule_name',
                                   text='Name',
                                   icon_value=0,
                                   emboss=True)
                    row_7B50A = row_99A09.row(heading='', align=False)
                    row_7B50A.alert = False
                    row_7B50A.enabled = os.path.exists(
                        bpy.context.scene.sna_md_topology_file
                    ) and os.path.exists(bpy.context.scene.sna_md_traj_file)
                    row_7B50A.use_property_split = False
                    row_7B50A.use_property_decorate = False
                    row_7B50A.scale_x = 1.0
                    row_7B50A.scale_y = 1.0
                    row_7B50A.alignment = 'Expand'.upper()
                    op = row_7B50A.operator(
                        'sna.import_structure_md_traj_f17a1',
                        text='Import Frames',
                        icon_value=125,
                        emboss=True,
                        depress=False)
                    op.sna_new_property = 'test'
                    box_011E3.label(text='Toplogy File (.pdb, .gro, etc...)',
                                    icon_value=458)
                    row_ABD6C = box_011E3.row(heading='', align=False)
                    row_ABD6C.alert = False
                    row_ABD6C.enabled = True
                    row_ABD6C.use_property_split = False
                    row_ABD6C.use_property_decorate = False
                    row_ABD6C.scale_x = 1.0
                    row_ABD6C.scale_y = 1.2000000476837158
                    row_ABD6C.alignment = 'Expand'.upper()
                    row_ABD6C.prop(bpy.context.scene,
                                   'sna_md_topology_file',
                                   text='File Path',
                                   icon_value=0,
                                   emboss=True)
                    box_011E3.label(
                        text='Trajectory File (.xtc, .dcd, etc...)',
                        icon_value=125)
                    row_4C186 = box_011E3.row(heading='', align=False)
                    row_4C186.alert = False
                    row_4C186.enabled = True
                    row_4C186.use_property_split = False
                    row_4C186.use_property_decorate = False
                    row_4C186.scale_x = 1.0
                    row_4C186.scale_y = 1.2000000476837158
                    row_4C186.alignment = 'Expand'.upper()
                    row_4C186.prop(bpy.context.scene,
                                   'sna_md_traj_file',
                                   text='File Path',
                                   icon_value=0,
                                   emboss=True)
                    box_011E3.label(text='Frame Import Options',
                                    icon_value=486)
                    col_27496 = box_011E3.column(
                        heading='Frame import options', align=True)
                    col_27496.alert = False
                    col_27496.enabled = True
                    col_27496.use_property_split = True
                    col_27496.use_property_decorate = False
                    col_27496.scale_x = 1.0
                    col_27496.scale_y = 1.0
                    col_27496.alignment = 'Center'.upper()
                    col_27496.prop(bpy.context.scene,
                                   'sna_md_frame_start',
                                   text='Start Frame',
                                   icon_value=0,
                                   emboss=True)
                    col_27496.prop(bpy.context.scene,
                                   'sna_md_frame_interval',
                                   text='Interval',
                                   icon_value=0,
                                   emboss=True)
                    col_27496.prop(bpy.context.scene,
                                   'sna_md_frame_end',
                                   text='End Frame',
                                   icon_value=0,
                                   emboss=True)
                    box_011E3.label(text='Model Import Options',
                                    icon_value=280)
                    row_3A456 = box_011E3.row(heading='', align=False)
                    row_3A456.alert = False
                    row_3A456.enabled = True
                    row_3A456.use_property_split = True
                    row_3A456.use_property_decorate = False
                    row_3A456.scale_x = 1.0
                    row_3A456.scale_y = 1.0
                    row_3A456.alignment = 'Expand'.upper()
                    row_3A456.prop(bpy.context.scene,
                                   'sna_nanometre_scale',
                                   text='Nanometre Scale',
                                   icon_value=0,
                                   emboss=True)
                else:
                    pass
    else:
        col_5D8FA.label(text='Coming Soon!', icon_value=0)


class SNA_OT_Import_Structure_Md_Traj_F17A1(bpy.types.Operator):
    bl_idname = "sna.import_structure_md_traj_f17a1"
    bl_label = "import_structure_md_traj"
    bl_description = "Import the MD topology and trajectory files"
    bl_options = {"REGISTER", "UNDO"}

    sna_new_property: bpy.props.StringProperty(name='New Property',
                                               description='',
                                               default='',
                                               subtype='NONE',
                                               maxlen=0)

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        file_top = bpy.context.scene.sna_md_topology_file
        file_traj = bpy.context.scene.sna_md_traj_file
        md_frame_start = bpy.context.scene.sna_md_frame_start
        md_frame_interval = bpy.context.scene.sna_md_frame_interval
        md_frame_end = bpy.context.scene.sna_md_frame_end
        molecule_name = bpy.context.scene.sna_molecule_name
        mdanalysis_dir_location = ''
        output_name = None
        unique_names = None
        base_model = None
        col_properties = None
        col_frames = None
        from logging import warning
        import sys
        import site
        import numpy as np

        def verify_user_sitepackages(mda_path):
            usersitepackagespath = site.getusersitepackages()
            if os.path.exists(usersitepackagespath
                              ) and usersitepackagespath not in sys.path:
                sys.path.append(usersitepackagespath)
            if os.path.exists(mda_path) and mda_path not in sys.path:
                sys.path.append(mda_path)

        verify_user_sitepackages(mdanalysis_dir_location)
        try:
            import MDAnalysis as mda
        except:
            warning("Unable to Import MDAnalysis")
        dict_elements = {
            "H": 1,
            "He": 2,
            "Li": 3,
            "Be": 4,
            "B": 5,
            "C": 6,
            "N": 7,
            "O": 8,
            "F": 9,
            "Ne": 10,
            "Na": 11,
            "Mg": 12,
            "Al": 13,
            "Si": 14,
            "P": 15,
            "S": 16,
            "Cl": 17,
            "Ar": 18,
            "K": 19,
            "Ca": 20,
            "Sc": 21,
            "Ti": 22,
            "V": 23,
            "Cr": 24,
            "Mn": 25,
            "Fe": 26,
            "Co": 27,
            "Ni": 28,
            "Cu": 29,
            "Zn": 30,
            "Ga": 31,
            "Ge": 32,
            "As": 33,
            "Se": 34,
            "Br": 35,
            "Kr": 36,
            "Rb": 37,
            "Sr": 38,
            "Y": 39,
            "Zr": 40,
            "Nb": 41,
            "Mo": 42,
            "Tc": 43,
            "Ru": 44,
            "Rh": 45,
            "Pd": 46,
            "Ag": 47,
            "Cd": 48,
            "In": 49,
            "Sn": 50,
            "Sb": 51,
            "Te": 52,
            "I": 53,
            "Xe": 54,
            "Cs": 55,
            "Ba": 56,
            "La": 57,
            "Ce": 58,
            "Pr": 59,
            "Nd": 60,
            "Pm": 61,
            "Sm": 62,
            "Eu": 63,
            "Gd": 64,
            "Tb": 65,
            "Dy": 66,
            "Ho": 67,
            "Er": 68,
            "Tm": 69,
            "Yb": 70,
            "Lu": 71,
            "Hf": 72,
            "Ta": 73,
            "W": 74,
            "Re": 75,
            "Os": 76,
            "Ir": 77,
            "Pt": 78,
            "Au": 79,
            "Hg": 80,
            "Tl": 81,
            "Pb": 82,
            "Bi": 83,
            "Po": 84,
            "At": 85,
            "Rn": 86,
            "Fr": 87,
            "Ra": 88,
            "Ac": 89,
            "Th": 90,
            "Pa": 91,
            "U": 92,
            "Np": 93,
            "Pu": 94,
            "Am": 95,
            "Cm": 96,
            "Bk": 97,
            "Cf": 98,
            "Es": 99,
            "Fm": 100,
            "Md": 101,
            "No": 102,
            "Lr": 103,
            "Vac": 104
        }
        # See if there is a collection called "Molecular Nodes", if so, set it to be the parent
        # collection, otherwise create one and link it to the scene collection.
        #top = "G:\\bjohnston\\BAJ_01\\box.gro"
        #
        # traj = "G:\\bjohnston\\BAJ_01\\md_nojump.xtc"
        # file_top = "C:\\Users\\BradyJohnston\\Downloads\\6vsb_2_2_2_traj_xtc\\last_frame_nos.pdb"
        # file_traj = "C:\\Users\\BradyJohnston\\Downloads\\6vsb_2_2_2_traj_xtc\\trj_nos.xtc"
        # setup the universe using MDAnalysis, for use later in the script
        u = mda.Universe(file_top, file_traj)
        # output_name = "spike"
        output_name = molecule_name
        # try to get the collection, returns None if collection doesn't exist
        parent_coll = bpy.data.collections.get('MolecularNodes')
        # if the collection doesn't exist, create it
        if not parent_coll:
            parent_coll = bpy.data.collections.new('MolecularNodes')
            bpy.context.scene.collection.children.link(parent_coll)
        # make the MolecularNodes collection active
        bpy.context.view_layer.active_layer_collection = bpy.context.view_layer.layer_collection.children[
            'MolecularNodes']
        # try:
        #     parent_coll = bpy.data.collections['MolecularNodes']
        #     parent_coll.name == "MolecularNodes"
        #     # make the collection active, for creating and disabling new
        #     bpy.context.view_layer.active_layer_collection = bpy.context.view_layer.layer_collection.children[
        #         'MolecularNodes']
        # except:
        #     parent_coll = bpy.data.collections.new('MolecularNodes')
        #     bpy.context.scene.collection.children.link(parent_coll)
        #     # make the collection active, for creating and disabling new
        #     bpy.context.view_layer.active_layer_collection = bpy.context.view_layer.layer_collection.children[
        #         'MolecularNodes']
        # create new collection that will house the data, link it to the parent collection
        col = bpy.data.collections.new(output_name)
        parent_coll.children.link(col)
        # create the properties collection
        col_properties = bpy.data.collections.new(output_name + "_properties")
        col.children.link(col_properties)

        def create_model(name, collection, locations, bonds=[], faces=[]):
            """
            Creates a mesh with the given name in the given collection, from the supplied
            values for the locationso of vertices, and if supplied, bonds and faces.
            """
            # create a new mesh
            atom_mesh = bpy.data.meshes.new(name)
            atom_mesh.from_pydata(locations, bonds, faces)
            new_object = bpy.data.objects.new(name, atom_mesh)
            collection.objects.link(new_object)
            return new_object

        def create_properties_model(name, collection, prop_x, prop_y, prop_z,
                                    n_atoms):
            """
            Creates a mesh that will act as a look up table for properties about the atoms
            in the actual mesh that will be created.
            """
            if n_atoms == None:
                n_atoms = len(prop_x)

            def get_value(vec, x):
                try:
                    return vec[x]
                except:
                    return 0

            list_list = list(
                map(
                    lambda x: [
                        get_value(prop_x, x),
                        get_value(prop_y, x),
                        get_value(prop_z, x)
                    ], range(n_atoms - 1)))
            create_model(name=name, collection=collection, locations=list_list)

        def create_prop_AtomicNum_ChainNum_NameNum(univ, name, collection):
            n = univ.atoms.n_atoms
            # get the atomic numbers for the atoms
            try:
                prop_elem_num = list(
                    map(lambda x: dict_elements.get(x, 0), u.atoms.elements))
            except:
                try:
                    prop_elem = list(
                        map(
                            lambda x: mda.topology.guessers.guess_atom_element(
                                x), univ.atoms.names))
                    prop_elem_num = list(
                        map(lambda x: dict_elements.get(x, 0), prop_elem))
                except:
                    prop_elem = []
                    for i in range(n - 1):
                        prop_elem.append(0)
            # get the chain numbers for the atoms
            try:
                prop_chain = univ.atoms.chainIDs
                unique_chains = np.array(list(set(prop_chain)))
                prop_chain_num = np.array(
                    list(
                        map(lambda x: np.where(x == unique_chains)[0][0],
                            prop_chain)))
            except:
                unique_chains = ["No Chains Found"]
                prop_chain_num = []
                for i in range(n - 1):
                    prop_chain_num.append(0)
            # get the name numbers
            try:
                prop_name = univ.atoms.names
                unique_names = np.array(list(set(prop_name)))
                prop_name_num = np.array(
                    list(
                        map(lambda x: np.where(x == unique_names)[0][0],
                            prop_name)))
            except:
                prop_name = []
                for i in range(n - 1):
                    prop_name.append(0)
            create_properties_model(name=name,
                                    collection=collection,
                                    prop_x=prop_elem_num,
                                    prop_y=prop_chain_num,
                                    prop_z=prop_name_num,
                                    n_atoms=n)
            return list(unique_chains)

        def create_prop_aaSeqNum_atomNum_atomAAIDNum(univ, name, collection):
            n = univ.atoms.n_atoms
            # get the AA sequence numebrs
            try:
                prop_aaSeqNum = univ.atoms.resnums
            except:
                prop_aaSeqNum = []
                for i in range(n - 1):
                    prop_aaSeqNum.append(0)
            # get the atom indices
            try:
                prop_atomNum = univ.atoms.ids
            except:
                prop_atomNum = range(1, n + 1)
            # get the residue names (AA names etc)
            try:
                resnames = univ.atoms.resnames
                unique_resnames = np.array(list(set(resnames)))
                prop_aa_ID_num = list(
                    map(lambda x: np.where(x == unique_resnames)[0][0],
                        resnames))
            except:
                prop_aa_ID_num = []
                for i in range(n - 1):
                    prop_aa_ID_num.append(0)
            create_properties_model(name=name,
                                    collection=collection,
                                    prop_x=prop_aaSeqNum,
                                    prop_y=prop_atomNum,
                                    prop_z=prop_aa_ID_num,
                                    n_atoms=n)

        def create_prop_bvalue_isBackbone_isCA(univ, name, collection):
            n = univ.atoms.n_atoms
            # setup bvalue properties, likely that most simulations won't actually
            # have bfactors, but here anyway to capture them if they do.
            try:
                prop_bvalue = univ.atoms.tempfactors
            except:
                prop_bvalue = []
                for i in range(n - 1):
                    prop_bvalue.append(0)
            # setup isBackbone properties, selects backbone for nucleic and protein
            try:
                prop_is_backbone = np.isin(
                    univ.atoms.ix,
                    univ.select_atoms('backbone or nucleicbackbone').ix.astype(
                        int))
            except:
                prop_is_backbone = []
                for i in range(n - 1):
                    prop_bvalue.append(0)
            try:
                # compare the indices against a subset of indices for only the alpah carbons,
                # convert it to ingeger of 0 = False and 1 = True
                prop_is_CA = np.isin(
                    univ.atoms.ix,
                    univ.select_atoms("name CA").ix).astype(int)
            except:
                prop_is_CA = []
                for i in range(n - 1):
                    prop_is_CA.append(0)
            create_properties_model(name=name,
                                    collection=collection,
                                    prop_x=prop_bvalue,
                                    prop_y=prop_is_backbone,
                                    prop_z=prop_is_CA,
                                    n_atoms=n)

        # create the first model, that will be the actual atomic model the user will interact with and display
        base_model = create_model(name=output_name,
                                  collection=col,
                                  locations=u.atoms.positions * 0.1,
                                  bonds=[])
        # create the models that will hold the properties associated with each atom
        unique_names = create_prop_AtomicNum_ChainNum_NameNum(
            univ=u,
            name=output_name + "_properties_1",
            collection=col_properties)
        create_prop_aaSeqNum_atomNum_atomAAIDNum(univ=u,
                                                 name=output_name +
                                                 "_properties_2",
                                                 collection=col_properties)
        create_prop_bvalue_isBackbone_isCA(univ=u,
                                           name=output_name + "_properties_3",
                                           collection=col_properties)
        # create the frames
        col_frames = bpy.data.collections.new(output_name + "_frames")
        col.children.link(col_frames)

        # for each model in the pdb, create a new object and add it to the frames collection
        # testing out the addition of points that represent the bfactors. You can then in theory
        # use the modulo of the index to be able to pick either the position or the bvalue for
        # each frame in the frames collection.
        def create_frames(universe,
                          collection,
                          start=1,
                          end=50000,
                          time_step=100,
                          name=output_name,
                          nm_scale=0.1):
            """
            From the given universe, add frames to the given collection from the start till the end, along the given time
            step for each frame.
            """
            counter = 1
            for ts in universe.trajectory:
                if counter % time_step == 0 and counter > start and counter < end:
                    create_model(name=output_name + "_frame_" + str(counter),
                                 collection=collection,
                                 locations=universe.atoms.positions * nm_scale)
                counter += 1

        # create the frames from the given universe, only along the given timesteps
        create_frames(universe=u,
                      collection=col_frames,
                      start=md_frame_start,
                      time_step=md_frame_interval,
                      end=md_frame_end,
                      name=output_name,
                      nm_scale=0.1)
        # hide the created frames collection and the properties collection
        bpy.context.layer_collection.children[col.name].children[
            col_frames.name].exclude = True
        bpy.context.layer_collection.children[col.name].children[
            col_properties.name].exclude = True
        # # try to get the Molecular Nodes modifier and select it, if not create one and select it
        # def create_starting_node_tree(collection_of_properties, obj):
        #     try:
        #         node_mod = obj.modifiers['MolecularNodes']
        #     except:
        #         node_mod = None
        #     if node_mod == None:
        #         node_mod = obj.modifiers.new("MolecularNodes", "NODES")
        #         obj.modifiers.active = node_mod
        #     else:
        #         obj.modifiers.active = node_mod
        #     node_mod.node_group.name = "MOL_" + str(output_name)
        #     node_input = node_mod.node_group.nodes['Group Input']
        #     node_input.location = [-200, 0]
        #     node_output = node_mod.node_group.nodes['Group Output']
        #     node_output.location = [600, 0]
        #     # create an empty node group and link it to the atomic properties node group
        #     new_node_group = node_mod.node_group.nodes.new("GeometryNodeGroup")
        #     new_node_group.node_tree = bpy.data.node_groups["MOL_atomic_properties"]
        #     new_node_group.inputs['Properties'].default_value = collection_of_properties
        #     new_node_group.location = [0, 0]
        #     # resize the newly created node to be a bit wider
        #     node_mod.node_group.nodes[-1].width = 200
        #     colour_node_group = node_mod.node_group.nodes.new("GeometryNodeGroup")
        #     colour_node_group.node_tree = bpy.data.node_groups["MOL_style_colour"]
        #     colour_node_group.location = [300, 0]
        #     node_mod.node_group.nodes[-1].width = 200
        #     link = node_mod.node_group.links.new
        #     link(node_input.outputs['Geometry'], new_node_group.inputs['Atoms'])
        #     link(new_node_group.outputs['Atoms'], colour_node_group.inputs['Atoms'])
        #     link(new_node_group.outputs['atomic_number'],
        #          colour_node_group.inputs['atomic_number'])
        #     link(colour_node_group.outputs['Atoms'], node_output.inputs['Geometry'])
        #     node_mod.node_group.outputs.new("NodeSocketColor", "Colour")
        #     link(colour_node_group.outputs['Colour'], node_output.inputs['Colour'])
        #     node_mod['Output_2_attribute_name'] = "Colour"
        #     mat = create_starting_material()
        #     colour_node_group.inputs['Material'].default_value = mat
        # def create_starting_material():
        #     try:
        #         mat = bpy.data.materials['MOL_atomic_material']
        #         return mat
        #     except:
        #         mat = None
        #     if mat == None:
        #         mat = bpy.data.materials.new('MOL_atomic_material')
        #     mat.use_nodes = True
        #     node_att = mat.node_tree.nodes.new("ShaderNodeAttribute")
        #     node_att.attribute_name = "Colour"
        #     node_att.location = [-300, 200]
        #     mat.node_tree.links.new(
        #         node_att.outputs['Color'], mat.node_tree.nodes['Principled BSDF'].inputs['Base Color'])
        #     return mat
        # # create_starting_material(base_model)
        # create_starting_node_tree(
        #     collection_of_properties=col_properties, obj=base_model)
        # base_model.select_set(True)
        # bpy.context.view_layer.objects.active = base_model
        # # bpy.context.active_object.data.materials.append(mat)
        sna_setup_node_tree_272D6(output_name, unique_names, base_model,
                                  col_properties, col_frames)
        return {"FINISHED"}

    def invoke(self, context, event):

        return self.execute(context)


class SNA_OT_Import_Protein_Local_Ecb16(bpy.types.Operator):
    bl_idname = "sna.import_protein_local_ecb16"
    bl_label = "import_protein_local"
    bl_description = "Open local structure file and import to Blender."
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        sna_func_import_structure_EE5B6(
            bpy.context.scene.sna_pdb_code,
            bpy.context.scene.sna_nanometre_scale, False,
            bpy.context.scene.sna_pdb_path,
            bpy.context.scene.sna_molecule_name,
            bpy.context.scene.sna_create_bonds,
            bpy.context.scene.sna_connect_cutoff,
            bpy.context.scene.sna_build_assembly,
            bpy.context.scene.sna_build_assembly_id)
        return {"FINISHED"}

    def invoke(self, context, event):

        return self.execute(context)


class SNA_OT_Import_Protein_Fetch_Pdb_4Cf80(bpy.types.Operator):
    bl_idname = "sna.import_protein_fetch_pdb_4cf80"
    bl_label = "import_protein_fetch_pdb"
    bl_description = "Download and open structure file from wwPDB"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        sna_func_import_structure_EE5B6(
            bpy.context.scene.sna_pdb_code,
            bpy.context.scene.sna_nanometre_scale, True,
            bpy.context.scene.sna_pdb_path,
            bpy.context.scene.sna_molecule_name,
            bpy.context.scene.sna_create_bonds,
            bpy.context.scene.sna_connect_cutoff,
            bpy.context.scene.sna_build_assembly,
            bpy.context.scene.sna_build_assembly_id)
        return {"FINISHED"}

    def invoke(self, context, event):

        return self.execute(context)


class SNA_MT_68580(bpy.types.Menu):
    bl_idname = "SNA_MT_68580"
    bl_label = ""

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw(self, context):
        layout = self.layout.column_flow(columns=1)
        layout_function = layout
        sna_panel_category_interface_632C8(layout_function, 'Import Structure',
                                           0, 169)

        layout_function = layout
        sna_panel_category_interface_632C8(layout_function, 'DNA nodes', 1,
                                           206)


def sna_setup_node_tree_272D6(output_name, unique_chains, base_model,
                              col_properties, col_farmes):
    base_model['output_name'] = output_name
    base_model['unique_chain_ids'] = unique_chains
    for i_26E1E in range(
            len([
                'MOL_atomic_properties', 'MOL_style_colour', 'MOL_animate',
                'MOL_animate_frames'
            ])):
        sna_just_append_node_group_D75AA([
            'MOL_atomic_properties', 'MOL_style_colour', 'MOL_animate',
            'MOL_animate_frames'
        ][i_26E1E])
    base_model = base_model
    col_properties = col_properties
    col_frames = col_farmes

    # try to get the Molecular Nodes modifier and select it, if not create one and select it
    def create_starting_node_tree(collection_of_properties, obj):
        try:
            node_mod = obj.modifiers['MolecularNodes']
        except:
            node_mod = None
        if node_mod == None:
            node_mod = obj.modifiers.new("MolecularNodes", "NODES")
            obj.modifiers.active = node_mod
        else:
            obj.modifiers.active = node_mod
        node_mod.node_group.name = "MOL_" + str(output_name)

        node_input = node_mod.node_group.nodes['Group Input']
        node_input.location = [-200, 0]
        node_output = node_mod.node_group.nodes['Group Output']
        node_output.location = [800, 0]
        # create an empty node group and link it to the atomic properties node group
        new_node_group = node_mod.node_group.nodes.new("GeometryNodeGroup")
        new_node_group.node_tree = bpy.data.node_groups[
            "MOL_atomic_properties"]
        new_node_group.inputs[
            'Properties'].default_value = collection_of_properties
        new_node_group.location = [0, 0]
        # resize the newly created node to be a bit wider
        node_mod.node_group.nodes[-1].width = 200
        colour_node_group = node_mod.node_group.nodes.new("GeometryNodeGroup")
        colour_node_group.node_tree = bpy.data.node_groups["MOL_style_colour"]
        colour_node_group.location = [550, 0]
        node_mod.node_group.nodes[-1].width = 200
        random_node = node_mod.node_group.nodes.new("FunctionNodeRandomValue")
        random_node.data_type = 'FLOAT_VECTOR'
        random_node.location = [300, -200]
        link = node_mod.node_group.links.new
        link(node_input.outputs['Geometry'], new_node_group.inputs['Atoms'])
        link(new_node_group.outputs['Atoms'],
             colour_node_group.inputs['Atoms'])
        link(new_node_group.outputs['atomic_number'],
             colour_node_group.inputs['atomic_number'])
        link(new_node_group.outputs['chain_number'], random_node.inputs['ID'])
        link(random_node.outputs[0], colour_node_group.inputs['Carbon'])
        link(colour_node_group.outputs['Atoms'],
             node_output.inputs['Geometry'])
        node_mod.node_group.outputs.new("NodeSocketColor", "Colour")
        link(colour_node_group.outputs['Colour'], node_output.inputs['Colour'])
        node_mod['Output_2_attribute_name'] = "Colour"
        mat = create_starting_material()
        colour_node_group.inputs['Material'].default_value = mat
        if col_frames:
            node_output.location = [1100, 0]
            animate_frames_node = node_mod.node_group.nodes.new(
                "GeometryNodeGroup")
            animate_frames_node.node_tree = bpy.data.node_groups[
                "MOL_animate_frames"]
            animate_frames_node.location = [800, 0]
            animate_frames_node.inputs[
                'Frames Collection'].default_value = col_frames
            animate_frames_node.inputs[
                'Absolute Frame Position'].default_value = True

            animate_node = node_mod.node_group.nodes.new("GeometryNodeGroup")
            animate_node.node_tree = bpy.data.node_groups["MOL_animate"]
            animate_node.location = [550, 300]
            link(colour_node_group.outputs['Atoms'],
                 animate_frames_node.inputs['Atoms'])
            link(animate_frames_node.outputs['Atoms'],
                 node_output.inputs['Geometry'])
            link(animate_node.outputs['Animate Mapped'],
                 animate_frames_node.inputs[2])

    def create_starting_material():
        try:
            mat = bpy.data.materials['MOL_atomic_material']
            return mat
        except:
            mat = None
        if mat == None:
            mat = bpy.data.materials.new('MOL_atomic_material')
        mat.use_nodes = True
        node_att = mat.node_tree.nodes.new("ShaderNodeAttribute")

        node_att.attribute_name = "Colour"
        node_att.location = [-300, 200]
        mat.node_tree.links.new(
            node_att.outputs['Color'],
            mat.node_tree.nodes['Principled BSDF'].inputs['Base Color'])
        return mat

    # create_starting_material(base_model)
    create_starting_node_tree(collection_of_properties=col_properties,
                              obj=base_model)
    base_model.select_set(True)
    bpy.context.view_layer.objects.active = base_model


    # bpy.context.active_object.data.materials.append(mat)
def sna_just_append_node_group_D75AA(node_group):
    if property_exists("bpy.data.node_groups[node_group]"):
        pass
    else:
        bpy.ops.wm.append(
            directory=os.path.join(os.path.dirname(__file__), 'assets',
                                   'molecular_nodes_append_file.blend') +
            r'\NodeTree',
            filename=node_group,
            link=False)


class SNA_MT_E081B(bpy.types.Menu):
    bl_idname = "SNA_MT_E081B"
    bl_label = ""

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw(self, context):
        layout = self.layout.column_flow(columns=1)
        layout_function = layout
        sna_append_node_interface_92BEE(layout_function, 'Animate',
                                        'MOL_animate', 0)
        layout_function = layout
        sna_append_node_interface_92BEE(layout_function, 'Animate Frames',
                                        'MOL_animate_frames', 0)
        layout_function = layout
        sna_append_node_interface_92BEE(layout_function,
                                        'Animate Mismatched Frames',
                                        'MOL_animate_frames_mismatched', 0)
        layout_function = layout
        sna_append_node_interface_92BEE(layout_function, 'Noise', 'MOL_noise',
                                        0)
        layout_function = layout
        sna_append_node_interface_92BEE(layout_function, 'Object Effect',
                                        'MOL_object_effect', 0)
        layout_function = layout
        sna_append_node_interface_92BEE(layout_function, 'Center Atom',
                                        'MOL_center_atom', 0)
        layout_function = layout
        sna_append_node_interface_92BEE(layout_function, 'Points in Volume',
                                        'MOL_points_volume', 0)


class SNA_MT_F5083(bpy.types.Menu):
    bl_idname = "SNA_MT_F5083"
    bl_label = "Testing"

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw(self, context):
        layout = self.layout.column_flow(columns=1)
        layout.menu('SNA_MT_43F2D', text='Properties', icon_value=201)
        layout.menu('SNA_MT_1C944', text='Styling', icon_value=77)
        layout.menu('SNA_MT_B7C1D', text='Selections', icon_value=256)
        layout.menu('SNA_MT_E081B', text='Animation', icon_value=409)
        layout.menu('SNA_MT_47239', text='Utilities', icon_value=92)


class SNA_MT_B7C1D(bpy.types.Menu):
    bl_idname = "SNA_MT_B7C1D"
    bl_label = ""

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw(self, context):
        layout = self.layout.column_flow(columns=1)
        op = layout.operator('sna.mol_append_node_2cff0',
                             text='AA Name',
                             icon_value=0,
                             emboss=True,
                             depress=False)
        op.sna_node_name = 'MOL_selection_AA_name'
        layout.separator(factor=1.0)
        layout_function = layout
        sna_chain_selection_interface_7DE5A(layout_function, )


def sna_append_node_interface_92BEE(layout_function, label, node, icon):
    pass
    op = layout_function.operator('sna.mol_append_node_2cff0',
                                  text=label,
                                  icon_value=icon,
                                  emboss=True,
                                  depress=False)
    op.sna_node_name = node


class SNA_OT_Mol_Append_Node_2Cff0(bpy.types.Operator):
    bl_idname = "sna.mol_append_node_2cff0"
    bl_label = "MOL_append_node"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    sna_node_name: bpy.props.StringProperty(name='node_name',
                                            description='',
                                            default='',
                                            subtype='NONE',
                                            maxlen=0)

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        sna_just_append_node_group_D75AA(self.sna_node_name)
        prev_context = bpy.context.area.type
        bpy.context.area.type = 'NODE_EDITOR'
        bpy.ops.node.add_node('INVOKE_DEFAULT', use_transform=True)
        bpy.context.area.type = prev_context
        bpy.context.active_node.node_tree = bpy.data.node_groups[
            self.sna_node_name]
        return {"FINISHED"}

    def invoke(self, context, event):

        return self.execute(context)


def sna_chain_selection_interface_7DE5A(layout_function, ):
    pass
    op = layout_function.operator(
        'sna.add_custom_node_group_5cf76',
        text=' '.join([
            bpy.context.view_layer.objects.active['output_name'],
            'Chain Selection'
        ]),
        icon_value=0,
        emboss=True,
        depress=False)
    op.sna_id_list_string = ';'.join(
        bpy.context.view_layer.objects.active['unique_chain_ids'])
    op.sna_output_name = bpy.context.view_layer.objects.active['output_name']


class SNA_OT_Add_Custom_Node_Group_5Cf76(bpy.types.Operator):
    bl_idname = "sna.add_custom_node_group_5cf76"
    bl_label = "add_custom_node_group"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    sna_id_list_string: bpy.props.StringProperty(name='id_list_string',
                                                 description='',
                                                 default='',
                                                 subtype='NONE',
                                                 maxlen=0)

    sna_output_name: bpy.props.StringProperty(name='output_name',
                                              description='',
                                              default='',
                                              subtype='NONE',
                                              maxlen=0)

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        sna_just_append_node_group_D75AA('MOL_utils_bool_chain')
        chain_id_list = self.sna_id_list_string.split(';')
        output_name = self.sna_output_name
        node_name = None

        # creates the data block for a boolean chain node. Useful for when
        # constructing custom selection nodes, to be able to repeatedly add the
        # boolean selection node. If the data block already exists, it will return that
        # data block to be used, if it doesn't, it will create the required data block
        # for a chained node.
        def create_bool_chain_data():
            try:
                bool_chain_data = bpy.data.node_groups['MOL_utils_bool_chain']
            except:
                bool_chain_data = None

            # check to see if the data block already exists, if it does just return that instead.
            if bool_chain_data != None:
                return bool_chain_data
            else:
                bgd = bool_group_data = bpy.data.node_groups.new(
                    "MOL_utils_bool_chain", "GeometryNodeTree")
                bool_group_in = bgd.nodes.new("NodeGroupInput")
                bool_group_in.location = [-200, 0]
                bgd.inputs.new("NodeSocketInt", "number_chain_in")
                bgd.inputs.new("NodeSocketBool", "bool_chain_in")
                bgd.inputs.new("NodeSocketInt", "number_matched")
                bgd.inputs.new("NodeSocketBool", "bool_include")
                bool_group_out = bgd.nodes.new("NodeGroupOutput")
                bgd.outputs.new("NodeSocketInt", "number_chain_out")
                bgd.outputs.new("NodeSocketBool", "bool_chain_out")
                bool_group_out.location = [600, 0]
                node_num_comp = bgd.nodes.new("FunctionNodeCompare")
                node_num_comp.data_type = "INT"
                node_num_comp.operation = "EQUAL"
                node_num_comp.location = [100, 100]
                node_bool_math_1 = bgd.nodes.new("FunctionNodeBooleanMath")
                node_bool_math_1.location = [100, -100]
                node_bool_math_2 = bgd.nodes.new("FunctionNodeBooleanMath")
                node_bool_math_2.operation = "OR"
                node_bool_math_2.location = [400, 0]
                link = bool_group_data.links.new
                link(bool_group_in.outputs["number_chain_in"],
                     node_num_comp.inputs[2])
                link(bool_group_in.outputs["number_chain_in"],
                     bool_group_out.inputs["number_chain_out"])
                link(bool_group_in.outputs["bool_chain_in"],
                     node_bool_math_2.inputs[0])
                link(bool_group_in.outputs["number_matched"],
                     node_num_comp.inputs[3])
                link(bool_group_in.outputs["bool_include"],
                     node_bool_math_1.inputs[1])
                link(node_num_comp.outputs[0], node_bool_math_1.inputs[0])
                link(node_bool_math_1.outputs[0], node_bool_math_2.inputs[1])
                link(node_bool_math_2.outputs[0],
                     bool_group_out.inputs["bool_chain_out"])
                return bool_group_data

        def add_bool_chain_node():
            obj = bpy.context.active_object
            # try to get the Molecular Nodes mofier, if not create one and select it
            # if already exists, just select it
            try:
                node_mod = obj.modifiers['MolecularNodes']
            except:
                node_mod = None
            if node_mod == None:
                node_mod = obj.modifiers.new("MolecularNodes", "NODES")
                obj.modifiers.active = node_mod
            else:
                obj.modifiers.active = node_mod
            try:
                bool_chain_data = bpy.data.node_groups['MOL_utils_bool_chain']
            except:
                bool_chain_data = None
            if bool_chain_data == None:
                bool_chain_data = create_bool_chain_data()

            # now that the data block is checked and setup, create a blank
            # group node and link the data block to the node.
            new_node = node_mod.node_group.nodes.new("GeometryNodeGroup")
            new_node.node_tree = bool_chain_data
            return new_node

        # add_bool_chain_node()
        def create_node_group(node_name, input_list, label_prefix="Chain "):
            """
            Given a an input_list, will create a node which takes an Integer input, 
            and has a boolean tick box for each item in the input list. The outputs will
            be the resulting selection and the inversion of the selection.
            Can contain a prefix for the resulting labels. Mostly used for constructing 
            chain selections when required for specific proteins.
            """
            # get the active object, might need to change to taking an object as an input
            # and making it active isntead, to be more readily applied to multiple objects
            obj = bpy.context.active_object
            # try to get the Molecular Nodes modifier and select it, if not create one and select it
            try:
                node_mod = obj.modifiers['MolecularNodes']
            except:
                node_mod = None
            if node_mod == None:
                node_mod = obj.modifiers.new("MolecularNodes", "NODES")
                obj.modifiers.active = node_mod
            else:
                obj.modifiers.active = node_mod
            # link shortcut for creating links between nodes
            link = node_mod.node_group.links.new
            # create the custom node group data block, where everything will go
            # also create the required group node input and position it
            chain_group = bpy.data.node_groups.new(node_name,
                                                   "GeometryNodeTree")
            chain_group_in = chain_group.nodes.new("NodeGroupInput")
            chain_group_in.location = [-200, 0]
            # create an input on group node input, which will take the field of integers
            # for selection against
            chain_group.inputs.new("NodeSocketInt", "chain_number")
            # create a boolean input for the group for each item in the list
            for chain_name in input_list:
                # create a boolean input for the name, and name it whatever the chain chain name is
                chain_group.inputs.new("NodeSocketBool",
                                       str(label_prefix) + str(chain_name))
            # shortcut for creating new nodes
            new_node = chain_group.nodes.new
            # distance horizontally to space all of the created nodes
            node_sep_dis = 180
            counter = 0
            for chain_name in input_list:
                current_node = chain_group.nodes.new("GeometryNodeGroup")
                current_node.node_tree = create_bool_chain_data()
                current_node.location = [counter * node_sep_dis, 200]
                current_node.inputs[
                    "number_matched"].default_value = counter + 1
                group_link = chain_group.links.new

                group_link(chain_group_in.outputs['chain_number'],
                           current_node.inputs["number_chain_in"])
                group_link(chain_group_in.outputs[counter + 1],
                           current_node.inputs["bool_include"])

                if counter > 0:
                    group_link(previous_node.outputs['number_chain_out'],
                               current_node.inputs['number_chain_in'])
                    group_link(previous_node.outputs['bool_chain_out'],
                               current_node.inputs['bool_chain_in'])

                previous_node = current_node
                counter += 1

            chain_group_out = chain_group.nodes.new("NodeGroupOutput")
            chain_group_out.location = [(counter + 1) * node_sep_dis, 200]
            chain_group.outputs.new("NodeSocketBool", "Selection")
            chain_group.outputs.new("NodeSocketBool", "Inverted")

            group_link(current_node.outputs['bool_chain_out'],
                       chain_group_out.inputs['Selection'])
            bool_math = chain_group.nodes.new("FunctionNodeBooleanMath")
            bool_math.location = [counter * node_sep_dis, 50]
            bool_math.operation = "NOT"
            group_link(current_node.outputs['bool_chain_out'],
                       bool_math.inputs[0])
            group_link(bool_math.outputs[0],
                       chain_group_out.inputs['Inverted'])
            # create an empty node group group inside of the node tree
            # link the just-created custom node group data to the node group in the tree
            # new_node_group = node_mod.node_group.nodes.new("GeometryNodeGroup")
            # new_node_group.node_tree = bpy.data.node_groups[chain_group.name]
            # resize the newly created node to be a bit wider
            # node_mod.node_group.nodes[-1].width = 200

        # the chain_id_list and output_name are passed in from the operator when it is called
        # these are custom properties that are associated with the object when it is initial created
        chain_list = chain_id_list
        node_name = "MOL_" + str(output_name) + "_selection_chain"
        # finally make the selection node!
        create_node_group(node_name, chain_list)
        # node = bpy.context.selected_nodes[0]
        # bpy.ops.transform.translate('INVOKE_DEFAULT')
        prev_context = bpy.context.area.type
        bpy.context.area.type = 'NODE_EDITOR'
        bpy.ops.node.add_node('INVOKE_DEFAULT', use_transform=True)
        bpy.context.area.type = prev_context
        bpy.context.active_node.node_tree = bpy.data.node_groups[node_name]
        return {"FINISHED"}

    def invoke(self, context, event):

        return self.execute(context)


class SNA_GROUP_sna_new_property(bpy.types.PropertyGroup):

    pass


def register():

    global _icons
    _icons = bpy.utils.previews.new()
    bpy.utils.register_class(SNA_GROUP_sna_new_property)
    bpy.types.Scene.sna_pdb_code = bpy.props.StringProperty(
        name='pdb_code',
        description='The PDB ID of the structre you would like to download.',
        options={'TEXTEDIT_UPDATE'},
        default='1bna',
        subtype='NONE',
        maxlen=4)
    bpy.types.Scene.sna_nanometre_scale = bpy.props.FloatProperty(
        name='nanometre_scale',
        description=
        'Scale the model so that one angstrom is this size in metres',
        default=1.0,
        subtype='NONE',
        unit='LENGTH',
        step=3,
        precision=3)
    bpy.types.Scene.sna_pdb_path = bpy.props.StringProperty(
        name='pdb_path',
        description='File path of the structure to open',
        options={'TEXTEDIT_UPDATE'},
        default='',
        subtype='FILE_PATH',
        maxlen=0)
    bpy.types.Scene.sna_molecule_name = bpy.props.StringProperty(
        name='molecule_name',
        description='Name to assign to the molecule when imported to Blender',
        options={'TEXTEDIT_UPDATE'},
        default='',
        subtype='NONE',
        maxlen=0)
    bpy.types.Scene.sna_create_bonds = bpy.props.BoolProperty(
        name='create_bonds',
        description=
        'Attempt to calculate bonds in the structure on import. Can be slow for large structures',
        options={'TEXTEDIT_UPDATE'},
        default=False)
    bpy.types.Scene.sna_connect_cutoff = bpy.props.FloatProperty(
        name='connect_cutoff',
        description='Cutoff value to consider atoms bonded.',
        default=0.3499999940395355,
        subtype='NONE',
        unit='NONE',
        step=3,
        precision=2)
    bpy.types.Scene.sna_build_assembly = bpy.props.BoolProperty(
        name='build_assembly',
        description=
        'Enable the building of biological assemblies that are pre-defined in the structure file',
        default=False)
    bpy.types.Scene.sna_build_assembly_id = bpy.props.IntProperty(
        name='build_assembly_id',
        description='ID of the biological assembly to build.',
        options={'HIDDEN'},
        default=1,
        subtype='NONE',
        min=1)
    bpy.types.Scene.sna_interface_display = bpy.props.IntProperty(
        name='interface_display', description='', default=0, subtype='NONE')
    bpy.types.Scene.sna_load_struc_mod_traj = bpy.props.IntProperty(
        name='load_struc_mod_traj', description='', default=0, subtype='NONE')
    bpy.types.Scene.sna_md_topology_file = bpy.props.StringProperty(
        name='md_topology_file',
        description='Path to the tpology file for the simulation.',
        options={'TEXTEDIT_UPDATE'},
        default='',
        subtype='FILE_PATH',
        maxlen=0)
    bpy.types.Scene.sna_md_traj_file = bpy.props.StringProperty(
        name='md_traj_file',
        description='Path to the trajectory file for the simulation.',
        options={'TEXTEDIT_UPDATE'},
        default='',
        subtype='FILE_PATH',
        maxlen=0)
    bpy.types.Scene.sna_md_frame_start = bpy.props.IntProperty(
        name='md_frame_start',
        description='First frame that will be imported from the trajectory',
        default=1,
        subtype='NONE',
        min=1)
    bpy.types.Scene.sna_md_frame_end = bpy.props.IntProperty(
        name='md_frame_end',
        description='Last frame that will be imported from the trajectory',
        default=5000,
        subtype='NONE',
        min=2)
    bpy.types.Scene.sna_md_frame_interval = bpy.props.IntProperty(
        name='md_frame_interval',
        description=
        'Import every nth frame. 1 imports all frames from the trajectory',
        default=100,
        subtype='NONE',
        min=1)
    bpy.types.Scene.sna_atomium_available = bpy.props.BoolProperty(
        name='atomium_available', description='', default=False)
    bpy.types.Scene.sna_dview_display = bpy.props.BoolProperty(
        name='3dview_display', description='', default=False)
    bpy.types.Scene.sna_test_preoprty = bpy.props.IntProperty(
        name='test_preoprty', description='', default=0, subtype='NONE')
    bpy.types.Scene.sna_protein_collection = bpy.props.CollectionProperty(
        name='protein_collection',
        description='',
        type=SNA_GROUP_sna_new_property)

    bpy.utils.register_class(SNA_MT_43F2D)
    bpy.types.NODE_MT_add.append(sna_add_to_node_mt_add_E78CC)
    bpy.utils.register_class(SNA_OT_Install_Atomium_Bd760)
    bpy.utils.register_class(SNA_AddonPreferences_9D182)
    bpy.utils.register_class(SNA_OT_Check_Mda_Install_66F5A)
    bpy.utils.register_class(SNA_MT_1C944)
    bpy.utils.register_class(SNA_MT_47239)
    bpy.utils.register_class(SNA_OT_Panel_Category_D9Ef0)
    bpy.utils.register_class(SNA_OT_Import_Method_6D000)
    bpy.utils.register_class(SNA_PT_MOLECULAR_NODES_82594)
    bpy.utils.register_class(SNA_PT_MOLECULAR_NODES_7D87B)
    bpy.utils.register_class(SNA_OT_Import_Structure_Md_Traj_F17A1)
    bpy.utils.register_class(SNA_OT_Import_Protein_Local_Ecb16)
    bpy.utils.register_class(SNA_OT_Import_Protein_Fetch_Pdb_4Cf80)
    bpy.utils.register_class(SNA_MT_68580)
    bpy.utils.register_class(SNA_MT_E081B)
    bpy.utils.register_class(SNA_MT_F5083)
    bpy.utils.register_class(SNA_MT_B7C1D)
    bpy.utils.register_class(SNA_OT_Mol_Append_Node_2Cff0)
    bpy.utils.register_class(SNA_OT_Add_Custom_Node_Group_5Cf76)


def unregister():

    global _icons
    bpy.utils.previews.remove(_icons)

    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    for km, kmi in addon_keymaps.values():
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    del bpy.types.Scene.sna_protein_collection
    del bpy.types.Scene.sna_test_preoprty
    del bpy.types.Scene.sna_dview_display
    del bpy.types.Scene.sna_atomium_available
    del bpy.types.Scene.sna_md_frame_interval
    del bpy.types.Scene.sna_md_frame_end
    del bpy.types.Scene.sna_md_frame_start
    del bpy.types.Scene.sna_md_traj_file
    del bpy.types.Scene.sna_md_topology_file
    del bpy.types.Scene.sna_load_struc_mod_traj
    del bpy.types.Scene.sna_interface_display
    del bpy.types.Scene.sna_build_assembly_id
    del bpy.types.Scene.sna_build_assembly
    del bpy.types.Scene.sna_connect_cutoff
    del bpy.types.Scene.sna_create_bonds
    del bpy.types.Scene.sna_molecule_name
    del bpy.types.Scene.sna_pdb_path
    del bpy.types.Scene.sna_nanometre_scale
    del bpy.types.Scene.sna_pdb_code
    bpy.utils.unregister_class(SNA_GROUP_sna_new_property)

    bpy.utils.unregister_class(SNA_MT_43F2D)
    bpy.types.NODE_MT_add.remove(sna_add_to_node_mt_add_E78CC)
    bpy.utils.unregister_class(SNA_OT_Install_Atomium_Bd760)
    bpy.utils.unregister_class(SNA_AddonPreferences_9D182)
    bpy.utils.unregister_class(SNA_OT_Check_Mda_Install_66F5A)
    bpy.utils.unregister_class(SNA_MT_1C944)
    bpy.utils.unregister_class(SNA_MT_47239)
    bpy.utils.unregister_class(SNA_OT_Panel_Category_D9Ef0)
    bpy.utils.unregister_class(SNA_OT_Import_Method_6D000)
    bpy.utils.unregister_class(SNA_PT_MOLECULAR_NODES_82594)
    bpy.utils.unregister_class(SNA_PT_MOLECULAR_NODES_7D87B)
    bpy.utils.unregister_class(SNA_OT_Import_Structure_Md_Traj_F17A1)
    bpy.utils.unregister_class(SNA_OT_Import_Protein_Local_Ecb16)
    bpy.utils.unregister_class(SNA_OT_Import_Protein_Fetch_Pdb_4Cf80)
    bpy.utils.unregister_class(SNA_MT_68580)
    bpy.utils.unregister_class(SNA_MT_E081B)
    bpy.utils.unregister_class(SNA_MT_F5083)
    bpy.utils.unregister_class(SNA_MT_B7C1D)
    bpy.utils.unregister_class(SNA_OT_Mol_Append_Node_2Cff0)
    bpy.utils.unregister_class(SNA_OT_Add_Custom_Node_Group_5Cf76)
