bl_info = {
    "name" : "Molecular Nodes",
    "author" : "Brady Johnston", 
    "description" : "A plugin and nodes for working with molecular data in Blender.",
    "blender" : (3, 0, 0),
    "version" : (0, 4, 0),
    "location" : "Perth, Australia",
    "waring" : "",
    "doc_url": "", 
    "tracker_url": "https://github.com/BradyAJohnston/MolecularNodes/issues", 
    "category" : "Molecular" 
}

import bpy
import bpy.utils.previews

import bpy
import bpy
import os
import subprocess
import os
import bpy
import re
import os
import bpy


def string_to_int(value):
    if value.isdigit():
        return int(value)
    return 0


def string_to_icon(value):
    if value in bpy.types.UILayout.bl_rna.functions["prop"].parameters[
            "icon"].enum_items.keys():
        return bpy.types.UILayout.bl_rna.functions["prop"].parameters[
            "icon"].enum_items[value].value
    return string_to_int(value)


def icon_to_string(value):
    for icon in bpy.types.UILayout.bl_rna.functions["prop"].parameters[
            "icon"].enum_items:
        if icon.value == value:
            return icon.name
    return "NONE"


def enum_set_to_string(value):
    if type(value) == set:
        if len(value) > 0:
            return "[" + (", ").join(list(value)) + "]"
        return "[]"
    return value


def string_to_type(value, to_type, default):
    try:
        value = to_type(value)
    except:
        value = default
    return value


addon_keymaps = {}
_icons = None
serpens_node_tree_1 = {}


def property_exists(prop_path):
    try:
        eval(prop_path)
        return True
    except:
        return False


def property_exists(prop_path):
    try:
        eval(prop_path)
        return True
    except:
        return False


class SNA_OT_Mol_Atomic_Properties_30300(bpy.types.Operator):
    bl_idname = "sna.mol_atomic_properties_30300"
    bl_label = "MOL_atomic_properties"
    bl_description = "Some documentation for this operator!"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        sna_append_add_node_3229D('MOL_atomic_properties')
        return {"FINISHED"}

    def invoke(self, context, event):

        return self.execute(context)


class SNA_OT_Mol_Scale_Radii_1163F(bpy.types.Operator):
    bl_idname = "sna.mol_scale_radii_1163f"
    bl_label = "MOL_scale_radii"
    bl_description = "Some documentation for this operator!"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        sna_append_add_node_3229D('MOL_scale_radii')
        return {"FINISHED"}

    def invoke(self, context, event):

        return self.execute(context)


class SNA_OT_Mol_Find_Bonds_58203(bpy.types.Operator):
    bl_idname = "sna.mol_find_bonds_58203"
    bl_label = "MOL_find_bonds"
    bl_description = "Some documentation for this operator!"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        sna_append_add_node_3229D('MOL_find_bonds')
        return {"FINISHED"}

    def invoke(self, context, event):

        return self.execute(context)


class SNA_MT_43F2D(bpy.types.Menu):
    bl_idname = "SNA_MT_43F2D"
    bl_label = ""

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw(self, context):
        layout = self.layout.column_flow(columns=1)
        op = layout.operator('sna.mol_atomic_properties_30300',
                             text='Atomic Properties',
                             icon_value=0,
                             emboss=True,
                             depress=False)
        op = layout.operator('sna.mol_scale_radii_1163f',
                             text='Scale Radii',
                             icon_value=0,
                             emboss=True,
                             depress=False)
        op = layout.operator('sna.mol_find_bonds_58203',
                             text='Find Bonds',
                             icon_value=0,
                             emboss=True,
                             depress=False)


def sna_add_to_node_mt_add_EDA2B(self, context):
    if not (not 'GeometryNodeTree' == bpy.context.area.spaces[0].tree_type):
        layout = self.layout
        layout.menu('SNA_MT_F5083', text='Molecular Nodes', icon_value=88)


def sna_append_add_node_3229D(new_node):
    new_node = new_node
    need_to_append = None
    new_node = new_node
    need_to_append = False
    try:
        bpy.data.node_groups.get(new_node).name == new_node
    except:
        need_to_append = True
    if need_to_append:
        bpy.ops.wm.append(
            directory=os.path.join(os.path.dirname(__file__), 'assets',
                                   'molecular_nodes_append_file.blend') +
            r'\NodeTree',
            filename=new_node,
            link=False)
    else:
        pass
    new_node = new_node
    # Get the currently active GN tree
    obj = bpy.context.active_object
    node_tree = obj.modifiers.active
    new_node = new_node
    # Add the new node group, will have been appended to the scene previously by the 'load_node' function
    bpy.ops.node.add_node(type="GeometryNodeGroup",
                          use_transform=True,
                          settings=[{
                              "name":
                              "node_tree",
                              "value":
                              "bpy.data.node_groups['" + new_node + "']"
                          }])
    # select the just-added node, and make it currently being transformed by the user
    node = bpy.context.selected_nodes[0]
    bpy.ops.transform.translate('INVOKE_DEFAULT')


class SNA_OT_Mol_Animate_C0484(bpy.types.Operator):
    bl_idname = "sna.mol_animate_c0484"
    bl_label = "MOL_animate"
    bl_description = "Some documentation for this operator!"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        sna_append_add_node_3229D('MOL_animate')
        return {"FINISHED"}

    def invoke(self, context, event):

        return self.execute(context)


class SNA_OT_Mol_Animate_Frames_036E7(bpy.types.Operator):
    bl_idname = "sna.mol_animate_frames_036e7"
    bl_label = "MOL_animate_frames"
    bl_description = "Some documentation for this operator!"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        sna_append_add_node_3229D('MOL_animate_frames')
        return {"FINISHED"}

    def invoke(self, context, event):

        return self.execute(context)


class SNA_OT_Mol_Noise_823C7(bpy.types.Operator):
    bl_idname = "sna.mol_noise_823c7"
    bl_label = "MOL_noise"
    bl_description = "Some documentation for this operator!"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        sna_append_add_node_3229D('MOL_noise')
        return {"FINISHED"}

    def invoke(self, context, event):

        return self.execute(context)


class SNA_OT_Mol_Object_Effect_0186D(bpy.types.Operator):
    bl_idname = "sna.mol_object_effect_0186d"
    bl_label = "MOL_object_effect"
    bl_description = "Some documentation for this operator!"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        sna_append_add_node_3229D('MOL_object_effect')
        return {"FINISHED"}

    def invoke(self, context, event):

        return self.execute(context)


class SNA_OT_Mol_Center_Atom_C6F3F(bpy.types.Operator):
    bl_idname = "sna.mol_center_atom_c6f3f"
    bl_label = "MOL_center_atom"
    bl_description = "Some documentation for this operator!"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        sna_append_add_node_3229D('MOL_center_atom')
        return {"FINISHED"}

    def invoke(self, context, event):

        return self.execute(context)


class SNA_MT_E081B(bpy.types.Menu):
    bl_idname = "SNA_MT_E081B"
    bl_label = ""

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw(self, context):
        layout = self.layout.column_flow(columns=1)
        op = layout.operator('sna.mol_animate_c0484',
                             text='Animate',
                             icon_value=0,
                             emboss=True,
                             depress=False)
        op = layout.operator('sna.mol_animate_frames_036e7',
                             text='Animate Frames',
                             icon_value=0,
                             emboss=True,
                             depress=False)
        op = layout.operator('sna.mol_noise_823c7',
                             text='Noise',
                             icon_value=0,
                             emboss=True,
                             depress=False)
        op = layout.operator('sna.mol_object_effect_0186d',
                             text='Object Effect',
                             icon_value=0,
                             emboss=True,
                             depress=False)
        op = layout.operator('sna.mol_center_atom_c6f3f',
                             text='Center Atom',
                             icon_value=0,
                             emboss=True,
                             depress=False)
        op = layout.operator('sna.mol_points_volume_88829',
                             text='Points in Volume',
                             icon_value=0,
                             emboss=True,
                             depress=False)


class SNA_OT_Mol_Points_Volume_88829(bpy.types.Operator):
    bl_idname = "sna.mol_points_volume_88829"
    bl_label = "MOL_points_volume"
    bl_description = "Some documentation for this operator!"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        sna_append_add_node_3229D('MOL_points_volume')
        return {"FINISHED"}

    def invoke(self, context, event):

        return self.execute(context)


class SNA_OT_Mol_Selection_Aa_Name_E7B4F(bpy.types.Operator):
    bl_idname = "sna.mol_selection_aa_name_e7b4f"
    bl_label = "MOL_selection_AA_name"
    bl_description = "Some documentation for this operator!"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        sna_append_add_node_3229D('MOL_selection_AA_name')
        return {"FINISHED"}

    def invoke(self, context, event):

        return self.execute(context)


class SNA_MT_B7C1D(bpy.types.Menu):
    bl_idname = "SNA_MT_B7C1D"
    bl_label = ""

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw(self, context):
        layout = self.layout.column_flow(columns=1)
        op = layout.operator('sna.mol_selection_aa_name_e7b4f',
                             text='AA Name',
                             icon_value=0,
                             emboss=True,
                             depress=False)
        layout.separator(factor=1.0)
        layout_function = layout
        sna_chain_selection_interface_7DE5A(layout_function, )


class SNA_MT_F5083(bpy.types.Menu):
    bl_idname = "SNA_MT_F5083"
    bl_label = "Testing"

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw(self, context):
        layout = self.layout.column_flow(columns=1)
        layout.menu('SNA_MT_43F2D', text='Properties', icon_value=201)
        layout.menu('SNA_MT_1C944', text='Styling', icon_value=77)
        layout.menu('SNA_MT_B7C1D', text='Selections', icon_value=256)
        layout.menu('SNA_MT_E081B', text='Animation', icon_value=409)
        layout.menu('SNA_MT_47239', text='Utilities', icon_value=92)


class SNA_AddonPreferences_9D182(bpy.types.AddonPreferences):
    bl_idname = 'molecular_nodes'

    def draw(self, context):
        if not (False):
            layout = self.layout
            layout.label(
                text='To install on Windows, start Blender as Administrator.',
                icon_value=2)
            layout.label(text='Install Atomium only required to run once.',
                         icon_value=0)
            op = layout.operator('sna.install_atomium_bd760',
                                 text='Install Atomium',
                                 icon_value=746,
                                 emboss=True,
                                 depress=False)


class SNA_OT_Install_Atomium_Bd760(bpy.types.Operator):
    bl_idname = "sna.install_atomium_bd760"
    bl_label = "install_atomium"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        atomium_install_successful = None
        import sys
        import site

        # path to python.exe
        python_exe = os.path.realpath(sys.executable)

        # upgrade pip
        subprocess.call([python_exe, "-m", "ensurepip"])
        subprocess.call(
            [python_exe, "-m", "pip", "install", "--upgrade", "pip"],
            timeout=600)

        # install required packages
        subprocess.call([python_exe, "-m", "pip", "install", "atomium"],
                        timeout=600)

        def verify_user_sitepackages():
            usersitepackagespath = site.getusersitepackages()
            if os.path.exists(usersitepackagespath
                              ) and usersitepackagespath not in sys.path:
                sys.path.append(usersitepackagespath)

        verify_user_sitepackages()
        try:
            import atomium
            atomium.fetch("1bna")
            atomium_install_successful = True
        except:
            atomium_install_successful = False
        if atomium_install_successful:
            self.report({'INFO'}, message='Successfully installed Atomium.')
        else:
            self.report({'INFO'}, message='Atomium installation failed.')
        return {"FINISHED"}

    def invoke(self, context, event):

        return self.execute(context)


def sna_chain_selection_interface_7DE5A(layout_function, ):
    pass
    op = layout_function.operator(
        'sna.ops_chain_selection_5cf76',
        text=' '.join([
            bpy.context.view_layer.objects.active['output_name'],
            'Chain Selection'
        ]),
        icon_value=0,
        emboss=True,
        depress=False)


def sna_func_import_structure_EE5B6(pdb_code, nanometre_scale, fetch_pdb,
                                    pdb_path, molecule_name, create_bonds,
                                    connect_cutoff, build_assembly,
                                    build_assembly_id):
    pdb_code = pdb_code
    nanometre_scale = nanometre_scale
    fetch_pdb = fetch_pdb
    pdb_path = pdb_path
    molecule_name = molecule_name
    create_bonds = create_bonds
    connect_cutoff = connect_cutoff
    build_assembly = build_assembly
    build_assembly_id = build_assembly_id
    output_name = None
    unique_chains = None
    base_model = None
    col_properties = None
    import numpy as np
    import sys
    import site

    def verify_user_sitepackages():
        usersitepackagespath = site.getusersitepackages()
        if os.path.exists(
                usersitepackagespath) and usersitepackagespath not in sys.path:
            sys.path.append(usersitepackagespath)

    verify_user_sitepackages()
    try:
        import atomium
    except:
        print("Atomium Not Installed")
    atom_name_dict = {
        'C': 1,
        "C1'": 2,
        'C2': 3,
        "C2'": 4,
        "C3'": 5,
        'C4': 6,
        "C4'": 7,
        'C5': 8,
        "C5'": 9,
        'C6': 10,
        'C7': 11,
        'C8': 12,
        'CA': 13,
        'CB': 14,
        'CD': 15,
        'CD1': 16,
        'CD2': 17,
        'CE': 18,
        'CE1': 19,
        'CE2': 20,
        'CG': 21,
        'CG1': 22,
        'CG2': 23,
        'CZ': 24,
        'N': 25,
        'N1': 26,
        'N2': 27,
        'N3': 28,
        'N4': 29,
        'NZ': 30,
        'O': 31,
        'O2': 32,
        "O3'": 33,
        'O4': 34,
        "O4'": 35,
        "O5'": 36,
        'O6': 37,
        'OD1': 38,
        'OD2': 39,
        'OE1': 40,
        'OE2': 41,
        'OG': 42,
        'OG1': 43,
        'OH': 44,
        'OP1': 45,
        'OP2': 46,
        'OXT': 47,
        'P': 48,
        'SD': 49,
        'SG': 50
    }
    element_dict = {
        "H": {
            "atomic_number": 1,
            "radii": 1.10
        },
        "He": {
            "atomic_number": 2,
            "radii": 1.40
        },
        "Li": {
            "atomic_number": 3,
            "radii": 1.82
        },
        "Be": {
            "atomic_number": 4,
            "radii": 1.53
        },
        "B": {
            "atomic_number": 5,
            "radii": 1.92
        },
        "C": {
            "atomic_number": 6,
            "radii": 1.70
        },
        "N": {
            "atomic_number": 7,
            "radii": 1.55
        },
        "O": {
            "atomic_number": 8,
            "radii": 1.52
        },
        "F": {
            "atomic_number": 9,
            "radii": 1.47
        },
        "Ne": {
            "atomic_number": 10,
            "radii": 1.54
        },
        "Na": {
            "atomic_number": 11,
            "radii": 2.27
        },
        "Mg": {
            "atomic_number": 12,
            "radii": 1.73
        },
        "Al": {
            "atomic_number": 13,
            "radii": 1.84
        },
        "Si": {
            "atomic_number": 14,
            "radii": 2.10
        },
        "P": {
            "atomic_number": 15,
            "radii": 1.80
        },
        "S": {
            "atomic_number": 16,
            "radii": 1.80
        },
        "Cl": {
            "atomic_number": 17,
            "radii": 1.75
        },
        "Ar": {
            "atomic_number": 18,
            "radii": 1.88
        },
        "K": {
            "atomic_number": 19,
            "radii": 2.75
        },
        "Ca": {
            "atomic_number": 20,
            "radii": 2.31
        }
    }
    radii_dict = {
        "H": 1.10,
        "He": 1.40,
        "Li": 1.82,
        "Be": 1.53,
        "B": 1.92,
        "C": 1.70,
        "N": 1.55,
        "O": 1.52,
        "F": 1.47,
        "Ne": 1.54,
        "Na": 2.27,
        "Mg": 1.73,
        "Al": 1.84,
        "Si": 2.10,
        "P": 1.80,
        "S": 1.80,
        "Cl": 1.75,
        "Ar": 1.88,
        "K": 2.75,
        "Ca": 2.31,
        "Sc": 2.11,

        # break in the elements, no longer in direct numerical order
        "Ni": 1.63,
        "Cu": 1.40,
        "Zn": 1.39
    }
    AA_dict = {
        # 20 naturally occurring amino acids
        "ALA": {
            "aa_number": 1,
            "aa_type": "polar",
            "aa_type_no": 1
        },
        "ARG": {
            "aa_number": 2,
            "aa_type": "polar",
            "aa_type_no": 1
        },
        "ASN": {
            "aa_number": 3,
            "aa_type": "polar",
            "aa_type_no": 1
        },
        "ASP": {
            "aa_number": 4,
            "aa_type": "polar",
            "aa_type_no": 1
        },
        "CYS": {
            "aa_number": 5,
            "aa_type": "polar",
            "aa_type_no": 1
        },
        "GLU": {
            "aa_number": 6,
            "aa_type": "polar",
            "aa_type_no": 1
        },
        "GLN": {
            "aa_number": 7,
            "aa_type": "polar",
            "aa_type_no": 1
        },
        "GLY": {
            "aa_number": 8,
            "aa_type": "polar",
            "aa_type_no": 1
        },
        "HIS": {
            "aa_number": 9,
            "aa_type": "polar",
            "aa_type_no": 1
        },
        "ILE": {
            "aa_number": 10,
            "aa_type": "polar",
            "aa_type_no": 1
        },
        "LEU": {
            "aa_number": 11,
            "aa_type": "polar",
            "aa_type_no": 1
        },
        "LYS": {
            "aa_number": 12,
            "aa_type": "polar",
            "aa_type_no": 1
        },
        "MET": {
            "aa_number": 13,
            "aa_type": "polar",
            "aa_type_no": 1
        },
        "PHE": {
            "aa_number": 14,
            "aa_type": "polar",
            "aa_type_no": 1
        },
        "PRO": {
            "aa_number": 15,
            "aa_type": "polar",
            "aa_type_no": 1
        },
        "SER": {
            "aa_number": 16,
            "aa_type": "polar",
            "aa_type_no": 1
        },
        "THR": {
            "aa_number": 17,
            "aa_type": "polar",
            "aa_type_no": 1
        },
        "TRP": {
            "aa_number": 18,
            "aa_type": "polar",
            "aa_type_no": 1
        },
        "TYR": {
            "aa_number": 19,
            "aa_type": "polar",
            "aa_type_no": 1
        },
        "VAL": {
            "aa_number": 20,
            "aa_type": "polar",
            "aa_type_no": 1
        },
        # unknown? Came up in one of the structures, haven't looked into it yet
        # TODO look into it!
        "UNK": {
            "aa_number": 21,
            "aa_type": "unkown",
            "aa_type_no": 1
        },
        ## nucleic acids
        ### DNA
        "DC": {
            "aa_number": 31,
            "aa_type": "unkown",
            "aa_type_no": 1
        },
        "DG": {
            "aa_number": 32,
            "aa_type": "unkown",
            "aa_type_no": 1
        },
        "DA": {
            "aa_number": 33,
            "aa_type": "unkown",
            "aa_type_no": 1
        },
        "DT": {
            "aa_number": 34,
            "aa_type": "unkown",
            "aa_type_no": 1
        },
        ### RNA
        "C": {
            "aa_number": 41,
            "aa_type": "unkown",
            "aa_type_no": 1
        },
        "G": {
            "aa_number": 42,
            "aa_type": "unkown",
            "aa_type_no": 1
        },
        "A": {
            "aa_number": 43,
            "aa_type": "unkown",
            "aa_type_no": 1
        },
        "U": {
            "aa_number": 44,
            "aa_type": "unkown",
            "aa_type_no": 1
        }
    }
    ###
    # The following variables are passed in when the operators are called, and it is set up properly by Serpens when built
    # They are thusly not defined in the actual code, but are included here for reference
    ###
    # create_bonds = True
    # pdb_code = "4ozs"
    # namometre_scale = 1
    # pdb_path = "C:\\Users\\bradyjohnston\\Desktop\\4ozs.pdb"
    # connect_cutoff = 0.35
    # build_assembly = True
    # build_assembly_id = 1
    pdb_id = pdb_code
    one_nanometre_size_in_metres = nanometre_scale * 0.1
    # download the required model
    if (fetch_pdb):
        pdb = atomium.fetch(pdb_id)
        output_name = pdb_id
    else:
        pdb_id = molecule_name
        pdb = atomium.open(pdb_path)
    if molecule_name == "":
        molecule_name = "new_molecule"
    if "pdb_id" not in vars():
        output_name = molecule_name
    pdb_backup = pdb
    # If true, the biological assembly will be built first and then imported.
    # This can likely be translated to a set of geometry nodes to reduce computation
    # time and also make it dynamic, but that will involve coding the creation of a bunch
    # of nodes which will be a nightmare. Colouring all of the atoms will be problematic as
    # well until the named attributes are properly released in blender 3.2, for now this
    # will be fine as viewport performance for the point clouds is very good. Will increase
    # the load times though depending on the assembly, as it will drastically increase the
    # number of atoms to iterate over.
    if build_assembly:
        # try to build the array with the given id, but if it fails (such as wrong id) continue on with the original mode.
        # TODO add a warning that will be displayed upon failure to build array.
        try:
            pdb = pdb.generate_assembly(build_assembly_id)
        except:
            print(
                Warning("Failed to generate biological assembly of id" +
                        str(build_assembly_id)))
    #pdb = atomium.open("C:\\Users\\BradyJohnston\\Desktop\\atp-frames.pdb")
    # check the number of models in the file
    if build_assembly:
        first_model = pdb
        n_models = 1
    else:
        first_model = pdb.models[0]
        n_models = len(pdb.models)
    n_atoms = len(first_model.atoms())
    all_chains = first_model.chains()
    # contains the atom number in the PDB file, acts as the index for everything.
    atom_id = []
    # contains the XYZ coordinates for the atom
    atom_location = []
    # contains the character sumbol of the element for the atom, i.e. 'H' for Hydrogen
    # and 'C' for Carbon
    atom_element_char = []
    # contains the atomic number of the number, has to be matched later against a
    # dictionary as the pip release of atomium doesn't currently have quick-access
    # to the atomic number, only the symbol
    atom_element_num = []
    # contains the name of the atom, which varies depending on where the atom appears
    # in the residue, C, C1' etc, with the second list being the numeric encoding of
    # this for use in geometry nodes
    atom_name_char = []
    atom_name_num = []
    # contains the letter code that is the representative of the chain that the
    # residue is part of, with the second list being the numeric encoding of this
    # for use in geometry nodes
    atom_chain_char = []
    atom_chain_num = []
    # contains the 3-letter codes that ID The AA side chain the atom is a part of,
    # or the single or two-letter codes for nucleic acids, with the second list
    # being the numeric encoding of this for use in geometry nodes
    atom_aa_id_char = []
    atom_aa_id_number = []
    # contains the integer representing the residue number in the sequence of the
    # protein that the atom is part of
    atom_aa_sequence_number = []
    # contains the b-factor for each atom, which is a representation of how
    # static the atom is when part of the overall structure
    atom_b_factor = []
    # contains TRUE / FALSE for whether the atom is part of the backbone
    atom_is_backbone = []
    # contains True / False for whether the atom is part of a sidechain
    atom_is_sidechain = []

    def try_lookup(dict, key, value_on_fail=0):
        """
        Try looking up the value from the key in the dictionary, 
        otherwise return the value on fail so that things can keep moving
        """
        try:
            return dict[key]
        except:
            return value_on_fail

    def try_append(list, value, value_on_fail=0):
        """
        Tries to append the value to the list, and adds instead the value on fail
        instead if a lookup into one of the dictionaries has failed.
        """
        try:
            list.append(value)
        except:
            list.append(value_on_fail)

    for chain in first_model.chains():
        current_chain = chain.id
        for res in chain.residues():
            current_aa_id_char = res.name
            # the numbers at the end of the AA identifier "ASP.19" etc
            current_aa_sequence_number = int(
                re.findall(r"\d+",
                           res.id.split(".")[1])[0])
            for atom in res.atoms():
                try_append(atom_id, atom.id)
                try_append(atom_location, atom.location)
                try_append(atom_element_char, atom.element)
                try_append(
                    atom_element_num,
                    try_lookup(element_dict[atom.element], "atomic_number"))
                try_append(atom_name_char, atom.name)
                try_append(atom_chain_char, current_chain)
                try_append(atom_aa_sequence_number, current_aa_sequence_number)
                try_append(atom_aa_id_char, current_aa_id_char)
                try_append(
                    atom_aa_id_number,
                    try_lookup(try_lookup(AA_dict, current_aa_id_char),
                               "aa_number"))
                # try_append(atom_aa_id_number, AA_dict[current_aa_id_char]["aa_number"])
                try_append(atom_b_factor, atom.bvalue)
                try_append(atom_is_backbone, int(atom.is_backbone))
                try_append(atom_is_sidechain, int(atom.is_side_chain))
    # turn all of the lists into numpy arrays, so that they can be rearranged based
    # on the atom indices created with np.argsort()
    atom_id = np.array(atom_id)
    atom_location = np.array(atom_location)
    atom_element_char = np.array(atom_element_char)
    atom_element_num = np.array(atom_element_num)
    atom_name_char = np.array(atom_name_char)
    # atom_name_num = np.array(atom_name_num)
    atom_chain_char = np.array(atom_chain_char)
    # atom_chain_num = np.array(atom_chain_num)
    atom_aa_id_char = np.array(atom_aa_id_char)
    atom_aa_id_number = np.array(atom_aa_id_number)
    atom_aa_sequence_number = np.array(atom_aa_sequence_number)
    atom_b_factor = np.array(atom_b_factor)
    atom_is_backbone = np.array(atom_is_backbone)
    atom_is_sidechain = np.array(atom_is_sidechain)
    inds = atom_id.argsort()
    # rearrange all of the arrays based on the indices, so that all values
    # match properly, and the atoms are in ascending order
    atom_id = atom_id[inds]
    atom_location = atom_location[inds]
    atom_element_char = atom_element_char[inds]
    atom_element_num = atom_element_num[inds]
    atom_name_char = atom_name_char[inds]
    # atom_name_num = atom_name_num[inds]
    atom_chain_char = atom_chain_char[inds]
    # atom_chain_num = atom_chain_num[inds]
    atom_aa_id_char = atom_aa_id_char[inds]
    atom_aa_id_number = atom_aa_id_number[inds]
    atom_aa_sequence_number = atom_aa_sequence_number[inds]
    atom_b_factor = atom_b_factor[inds]
    atom_is_backbone = atom_is_backbone[inds]
    atom_is_sidechain = atom_is_sidechain[inds]
    unique_chains = np.array(list(set(atom_chain_char)))
    chain_inds = unique_chains.argsort()
    unique_chains = unique_chains[chain_inds]
    atom_chain_num = list(
        map(lambda x: int(np.where(x == unique_chains)[0]), atom_chain_char))
    atom_chain_num = np.array(atom_chain_num)
    unique_atoms = np.array(list(set(atom_name_char)))
    unique_atoms_inds = unique_atoms.argsort()
    unique_atoms = unique_atoms[unique_atoms_inds]
    atom_name_num = list(
        map(lambda x: int(try_lookup(atom_name_dict, x)), atom_name_char))
    atom_name_num = np.array(atom_name_num)

    def create_model(name, collection, locations, bonds=[], faces=[]):
        """
        Creates a mesh with the given name in the given collection, from the supplied
        values for the locationso of vertices, and if supplied, bonds and faces.
        """
        # create a new mesh
        atom_mesh = bpy.data.meshes.new(name)
        atom_mesh.from_pydata(locations, bonds, faces)
        new_object = bpy.data.objects.new(name, atom_mesh)
        collection.objects.link(new_object)
        return new_object

    def create_properties_model(name, collection, prop_x, prop_y, prop_z):
        """
        Creates a mesh that will act as a look up table for properties about the atoms
        in the actual mesh that will be created.
        """

        def get_value(vec, x):
            try:
                return vec[x]
            except:
                return 0

        create_model(name=name,
                     collection=collection,
                     locations=list(
                         map(
                             lambda x: [
                                 get_value(prop_x, x),
                                 get_value(prop_y, x),
                                 get_value(prop_z, x)
                             ], range(len(atom_aa_sequence_number) - 1))))

    def get_bond_list(model, connect_cutoff=0.35, search_distance=3):
        """
        For all atoms in the model, search for the nearby atoms given the current 
        distance cutoff, then calculate whether or not they will be bonded to their 
        nearby atoms.
        Returns a list of lists, each with two integers in them, specifying the 
        atoms that are to be bonded.
        """
        mod = model
        mod.optimise_distances()
        for atom in mod.atoms():
            primary_atom = atom
            primary_radius = radii_dict[atom.element]
            nearby_atoms = atom.nearby_atoms(search_distance)
            if atom.element == "H":
                connect_adjust = -0.2
            else:
                connect_adjust = 0
            for secondary_atom in nearby_atoms:
                secondary_radius = radii_dict[secondary_atom.element]
                distance = atom.distance_to(secondary_atom)
                if distance <= ((connect_cutoff + connect_adjust) +
                                (primary_radius + secondary_radius) / 2):
                    primary_atom.bond(secondary_atom)
        for atom in mod.atoms():
            if len(atom.bonded_atoms) > 0:
                print(atom.bonded_atoms)
        all_atoms = mod.atoms()
        all_ids = np.array(list(map(lambda x: x.id, all_atoms)))
        inds = all_ids.argsort()
        all_ids = all_ids[inds]
        bond_list = []
        for atom in all_atoms:
            for atom2 in atom.bonded_atoms:
                bond_list.append([
                    int(np.where(atom.id == all_ids)[0]),
                    int(np.where(atom2.id == all_ids)[0])
                ])
        return bond_list

    def get_frame_positions(frame):
        """
        Returns a numpy array of all of the atom locations from the given frame. 
        Importantly it orders them according to their atom numbering to sync the frames.
        """
        all_atoms = frame.atoms()
        atom_id = list(map(lambda x: x.id, all_atoms))
        atom_location = list(map(lambda x: x.location, all_atoms))
        atom_id = np.array(atom_id)
        inds = atom_id.argsort()
        atom_id = atom_id[inds]
        atom_location = np.array(atom_location)
        atom_location = atom_location[inds]
        return atom_location

    # See if there is a collection called "Molecular Nodes", if so, set it to be the parent
    # collection, otherwise create one and link it to the scene collection.
    try:
        parent_coll = bpy.data.collections['MolecularNodes']
        parent_coll.name == "MolecularNodes"
        # make the collection active, for creating and disabling new
        bpy.context.view_layer.active_layer_collection = bpy.context.view_layer.layer_collection.children[
            'MolecularNodes']
    except:
        parent_coll = bpy.data.collections.new('MolecularNodes')
        bpy.context.scene.collection.children.link(parent_coll)
        # make the collection active, for creating and disabling new
        bpy.context.view_layer.active_layer_collection = bpy.context.view_layer.layer_collection.children[
            'MolecularNodes']
    # create new collection that will house the data, link it to the parent collection
    col = bpy.data.collections.new(pdb_id)
    parent_coll.children.link(col)
    col_properties = bpy.data.collections.new(pdb_id + "_properties")
    col.children.link(col_properties)
    # If create_bonds selected, generate a list of vertex pairs that will be the bonds for the atomic mesh,
    # else return an empty list that will make no edges when passed to create_model()
    if create_bonds:
        bonds = get_bond_list(first_model, connect_cutoff=connect_cutoff)
    else:
        bonds = []
    # create the first model, that will be the actual atomic model the user will interact with and display
    base_model = create_model(name=pdb_id,
                              collection=col,
                              locations=get_frame_positions(first_model) *
                              one_nanometre_size_in_metres,
                              bonds=bonds)
    # Creat the different models that will encode the various properties into
    # the XYZ locations of ther vertices.
    create_properties_model(
        name=pdb_id + "_properties_1",
        collection=col_properties,
        prop_x=atom_element_num,
        prop_y=atom_chain_num + 1,  # to have the first chain be indexed from 1
        prop_z=atom_name_num)
    create_properties_model(name=pdb_id + "_properties_2",
                            collection=col_properties,
                            prop_x=atom_aa_sequence_number,
                            prop_y=atom_id,
                            prop_z=atom_aa_id_number)
    create_properties_model(name=pdb_id + "_properties_3",
                            collection=col_properties,
                            prop_x=atom_b_factor,
                            prop_y=atom_is_backbone,
                            prop_z=atom_is_sidechain)
    # hide the created properties collection
    bpy.context.layer_collection.children[col.name].children[
        col_properties.name].exclude = True
    if (n_models > 1):
        frames_collection = bpy.data.collections.new(pdb_id + "_frames")
        col.children.link(frames_collection)
        # for each model in the pdb, create a new object and add it to the frames collection
        for frame in pdb_backup.models:
            atom_location = get_frame_positions(frame)
            create_model(name="frame_" + pdb_id,
                         collection=frames_collection,
                         locations=atom_location *
                         one_nanometre_size_in_metres)

        # hide the created frames collection
        bpy.context.layer_collection.children[col.name].children[
            frames_collection.name].exclude = True
    base_model['output_name'] = output_name
    base_model['unique_chain_ids'] = unique_chains
    if property_exists("bpy.data.node_groups['MOL_atomic_properties']"):
        pass
    else:
        bpy.ops.wm.append(
            directory=
            r'C:\Users\BradyJohnston\Documents\GitHub\MolecularNodes\molecular_nodes_append_file.blend'
            + r'\NodeTree',
            filename='MOL_atomic_properties',
            link=False)
    if property_exists("bpy.data.node_groups['MOL_style_colour']"):
        pass
    else:
        bpy.ops.wm.append(
            directory=
            r'C:\Users\BradyJohnston\Documents\GitHub\MolecularNodes\molecular_nodes_append_file.blend'
            + r'\NodeTree',
            filename='MOL_style_colour',
            link=False)
    base_model = base_model
    col_properties = col_properties

    # try to get the Molecular Nodes modifier and select it, if not create one and select it
    def create_starting_node_tree(collection_of_properties, obj):
        try:
            node_mod = obj.modifiers['MolecularNodes']
        except:
            node_mod = None
        if node_mod == None:
            node_mod = obj.modifiers.new("MolecularNodes", "NODES")
            obj.modifiers.active = node_mod
        else:
            obj.modifiers.active = node_mod
        node_mod.node_group.name = "MOL_" + str(output_name)

        node_input = node_mod.node_group.nodes['Group Input']
        node_input.location = [-200, 0]
        node_output = node_mod.node_group.nodes['Group Output']
        node_output.location = [600, 0]
        # create an empty node group and link it to the atomic properties node group
        new_node_group = node_mod.node_group.nodes.new("GeometryNodeGroup")
        new_node_group.node_tree = bpy.data.node_groups[
            "MOL_atomic_properties"]
        new_node_group.inputs[
            'Properties'].default_value = collection_of_properties
        new_node_group.location = [0, 0]
        # resize the newly created node to be a bit wider
        node_mod.node_group.nodes[-1].width = 200
        colour_node_group = node_mod.node_group.nodes.new("GeometryNodeGroup")
        colour_node_group.node_tree = bpy.data.node_groups["MOL_style_colour"]
        colour_node_group.location = [300, 0]
        node_mod.node_group.nodes[-1].width = 200
        link = node_mod.node_group.links.new
        link(node_input.outputs['Geometry'], new_node_group.inputs['Atoms'])
        link(new_node_group.outputs['Atoms'],
             colour_node_group.inputs['Atoms'])
        link(new_node_group.outputs['atomic_number'],
             colour_node_group.inputs['atomic_number'])
        link(colour_node_group.outputs['Atoms'],
             node_output.inputs['Geometry'])
        node_mod.node_group.outputs.new("NodeSocketColor", "Colour")
        link(colour_node_group.outputs['Colour'], node_output.inputs['Colour'])
        node_mod['Output_2_attribute_name'] = "Colour"
        mat = create_starting_material()
        colour_node_group.inputs['Material'].default_value = mat

    def create_starting_material():
        try:
            mat = bpy.data.materials['MOL_atomic_material']
            return mat
        except:
            mat = None
        if mat == None:
            mat = bpy.data.materials.new('MOL_atomic_material')
        mat.use_nodes = True
        node_att = mat.node_tree.nodes.new("ShaderNodeAttribute")

        node_att.attribute_name = "Colour"
        node_att.location = [-300, 200]
        mat.node_tree.links.new(
            node_att.outputs['Color'],
            mat.node_tree.nodes['Principled BSDF'].inputs['Base Color'])
        return mat

    # create_starting_material(base_model)
    create_starting_node_tree(collection_of_properties=col_properties,
                              obj=base_model)
    base_model.select_set(True)
    bpy.context.view_layer.objects.active = base_model


    # bpy.context.active_object.data.materials.append(mat)
class SNA_PT_MOLECULAR_NODES_86768(bpy.types.Panel):
    bl_label = 'Molecular Nodes'
    bl_idname = 'SNA_PT_MOLECULAR_NODES_86768'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'Molecular Nodes'
    bl_order = 0

    bl_ui_units_x = 0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        layout.label(text='Download from the PDB', icon_value=0)
        box_008BF = layout.box()
        box_008BF.alert = False
        box_008BF.enabled = True
        box_008BF.use_property_split = False
        box_008BF.use_property_decorate = False
        box_008BF.alignment = 'Expand'.upper()
        box_008BF.scale_x = 1.0
        box_008BF.scale_y = 1.2999999523162842
        row_ABB7D = box_008BF.row(heading='', align=False)
        row_ABB7D.alert = False
        row_ABB7D.enabled = True
        row_ABB7D.use_property_split = False
        row_ABB7D.use_property_decorate = False
        row_ABB7D.scale_x = 2.9679999351501465
        row_ABB7D.scale_y = 1.0
        row_ABB7D.alignment = 'Expand'.upper()
        row_ABB7D.prop(bpy.context.scene,
                       'sna_pdb_code',
                       text='PDB',
                       icon_value=0,
                       emboss=True)
        op = row_ABB7D.operator('sna.import_protein_fetch_pdb_4cf80',
                                text='Download',
                                icon_value=169,
                                emboss=True,
                                depress=False)
        layout.separator(factor=1.0)
        layout.label(text='Open Local File', icon_value=0)
        box_00078 = layout.box()
        box_00078.alert = False
        box_00078.enabled = True
        box_00078.use_property_split = False
        box_00078.use_property_decorate = False
        box_00078.alignment = 'Expand'.upper()
        box_00078.scale_x = 1.0
        box_00078.scale_y = 1.2999999523162842
        row_3131A = box_00078.row(heading='', align=False)
        row_3131A.alert = False
        row_3131A.enabled = True
        row_3131A.use_property_split = False
        row_3131A.use_property_decorate = False
        row_3131A.scale_x = 1.0
        row_3131A.scale_y = 1.0
        row_3131A.alignment = 'Expand'.upper()
        row_3131A.prop(bpy.context.scene,
                       'sna_molecule_name',
                       text='Name',
                       icon_value=0,
                       emboss=True)
        op = row_3131A.operator('sna.import_protein_local_ecb16',
                                text='Open',
                                icon_value=169,
                                emboss=True,
                                depress=False)
        box_00078.label(text='Files supported: *.pdb, *.mmtf, *.cif, *.gz',
                        icon_value=0)
        box_00078.prop(bpy.context.scene,
                       'sna_pdb_path',
                       text='PDB File',
                       icon_value=0,
                       emboss=True)
        layout.separator(factor=1.0)
        layout.label(text='Import Options', icon_value=0)
        box_2E2C0 = layout.box()
        box_2E2C0.alert = False
        box_2E2C0.enabled = True
        box_2E2C0.use_property_split = False
        box_2E2C0.use_property_decorate = False
        box_2E2C0.alignment = 'Expand'.upper()
        box_2E2C0.scale_x = 1.0
        box_2E2C0.scale_y = 1.0
        box_2E2C0.label(text='Calculate Bonded Atoms from Structure',
                        icon_value=0)
        box_2E2C0.label(text='(Can be slow on large structures)', icon_value=0)
        box_7F095 = box_2E2C0.box()
        box_7F095.alert = False
        box_7F095.enabled = True
        box_7F095.use_property_split = False
        box_7F095.use_property_decorate = False
        box_7F095.alignment = 'Expand'.upper()
        box_7F095.scale_x = 1.0
        box_7F095.scale_y = 1.0
        row_A1800 = box_7F095.row(heading='', align=False)
        row_A1800.alert = False
        row_A1800.enabled = True
        row_A1800.use_property_split = False
        row_A1800.use_property_decorate = False
        row_A1800.scale_x = 1.0
        row_A1800.scale_y = 1.0
        row_A1800.alignment = 'Left'.upper()
        row_A1800.prop(bpy.context.scene,
                       'sna_connect_cutoff',
                       text='Bond Cutoff',
                       icon_value=0,
                       emboss=True)
        row_A1800.prop(bpy.context.scene,
                       'sna_create_bonds',
                       text='Create Bonds',
                       icon_value=0,
                       emboss=True)
        box_2E2C0.label(text='Build Biological Assembly', icon_value=0)
        box_DF5F8 = box_2E2C0.box()
        box_DF5F8.alert = False
        box_DF5F8.enabled = True
        box_DF5F8.use_property_split = False
        box_DF5F8.use_property_decorate = False
        box_DF5F8.alignment = 'Expand'.upper()
        box_DF5F8.scale_x = 1.0
        box_DF5F8.scale_y = 1.0
        row_6617D = box_DF5F8.row(heading='', align=False)
        row_6617D.alert = False
        row_6617D.enabled = True
        row_6617D.use_property_split = False
        row_6617D.use_property_decorate = False
        row_6617D.scale_x = 1.0
        row_6617D.scale_y = 1.0
        row_6617D.alignment = 'Left'.upper()
        row_6617D.prop(bpy.context.scene,
                       'sna_build_assembly_id',
                       text='Assembly ID',
                       icon_value=0,
                       emboss=True)
        row_6617D.prop(bpy.context.scene,
                       'sna_build_assembly',
                       text='Build',
                       icon_value=0,
                       emboss=True)
        box_2E2C0.label(text='Adjust Structure Size', icon_value=0)
        box_60F24 = box_2E2C0.box()
        box_60F24.alert = False
        box_60F24.enabled = True
        box_60F24.use_property_split = False
        box_60F24.use_property_decorate = False
        box_60F24.alignment = 'Expand'.upper()
        box_60F24.scale_x = 1.0
        box_60F24.scale_y = 1.0
        box_60F24.label(text='1 nm will be rescaled to this size.',
                        icon_value=0)
        box_60F24.prop(bpy.context.scene,
                       'sna_nanometre_scale',
                       text='Nanometre Scale',
                       icon_value=0,
                       emboss=True)


class SNA_OT_Import_Protein_Fetch_Pdb_4Cf80(bpy.types.Operator):
    bl_idname = "sna.import_protein_fetch_pdb_4cf80"
    bl_label = "import_protein_fetch_pdb"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        sna_func_import_structure_EE5B6(
            bpy.context.scene.sna_pdb_code,
            bpy.context.scene.sna_nanometre_scale, True,
            bpy.context.scene.sna_pdb_path,
            bpy.context.scene.sna_molecule_name,
            bpy.context.scene.sna_create_bonds,
            bpy.context.scene.sna_connect_cutoff,
            bpy.context.scene.sna_build_assembly,
            bpy.context.scene.sna_build_assembly_id)
        return {"FINISHED"}

    def invoke(self, context, event):

        return context.window_manager.invoke_confirm(self, event)


class SNA_OT_Import_Protein_Local_Ecb16(bpy.types.Operator):
    bl_idname = "sna.import_protein_local_ecb16"
    bl_label = "import_protein_local"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        sna_func_import_structure_EE5B6(
            bpy.context.scene.sna_pdb_code,
            bpy.context.scene.sna_nanometre_scale, False,
            bpy.context.scene.sna_pdb_path,
            bpy.context.scene.sna_molecule_name,
            bpy.context.scene.sna_create_bonds,
            bpy.context.scene.sna_connect_cutoff,
            bpy.context.scene.sna_build_assembly,
            bpy.context.scene.sna_build_assembly_id)
        return {"FINISHED"}

    def invoke(self, context, event):

        return context.window_manager.invoke_confirm(self, event)


class SNA_OT_Ops_Chain_Selection_5Cf76(bpy.types.Operator):
    bl_idname = "sna.ops_chain_selection_5cf76"
    bl_label = "ops_chain_selection"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        if property_exists("bpy.data.node_groups['MOL_utils_bool_chain']"):
            pass
        else:
            bpy.ops.wm.append(
                directory=
                r'C:\Users\BradyJohnston\Documents\GitHub\MolecularNodes\molecular_nodes_append_file.blend'
                + r'\NodeTree',
                filename='MOL_utils_bool_chain',
                link=False)
        chain_id_list = bpy.context.view_layer.objects.active[
            'unique_chain_ids']
        output_name = bpy.context.view_layer.objects.active['output_name']

        # creates the data block for a boolean chain node. Useful for when
        # constructing custom selection nodes, to be able to repeatedly add the
        # boolean selection node. If the data block already exists, it will return that
        # data block to be used, if it doesn't, it will create the required data block
        # for a chained node.
        def create_bool_chain_data():
            try:
                bool_chain_data = bpy.data.node_groups['MOL_utils_bool_chain']
            except:
                bool_chain_data = None

            # check to see if the data block already exists, if it does just return that instead.
            if bool_chain_data != None:
                return bool_chain_data
            else:
                bgd = bool_group_data = bpy.data.node_groups.new(
                    "MOL_utils_bool_chain", "GeometryNodeTree")
                bool_group_in = bgd.nodes.new("NodeGroupInput")
                bool_group_in.location = [-200, 0]
                bgd.inputs.new("NodeSocketInt", "number_chain_in")
                bgd.inputs.new("NodeSocketBool", "bool_chain_in")
                bgd.inputs.new("NodeSocketInt", "number_matched")
                bgd.inputs.new("NodeSocketBool", "bool_include")
                bool_group_out = bgd.nodes.new("NodeGroupOutput")
                bgd.outputs.new("NodeSocketInt", "number_chain_out")
                bgd.outputs.new("NodeSocketBool", "bool_chain_out")
                bool_group_out.location = [600, 0]
                node_num_comp = bgd.nodes.new("FunctionNodeCompare")
                node_num_comp.data_type = "INT"
                node_num_comp.operation = "EQUAL"
                node_num_comp.location = [100, 100]
                node_bool_math_1 = bgd.nodes.new("FunctionNodeBooleanMath")
                node_bool_math_1.location = [100, -100]
                node_bool_math_2 = bgd.nodes.new("FunctionNodeBooleanMath")
                node_bool_math_2.operation = "OR"
                node_bool_math_2.location = [400, 0]
                link = bool_group_data.links.new
                link(bool_group_in.outputs["number_chain_in"],
                     node_num_comp.inputs[2])
                link(bool_group_in.outputs["number_chain_in"],
                     bool_group_out.inputs["number_chain_out"])
                link(bool_group_in.outputs["bool_chain_in"],
                     node_bool_math_2.inputs[0])
                link(bool_group_in.outputs["number_matched"],
                     node_num_comp.inputs[3])
                link(bool_group_in.outputs["bool_include"],
                     node_bool_math_1.inputs[1])
                link(node_num_comp.outputs[0], node_bool_math_1.inputs[0])
                link(node_bool_math_1.outputs[0], node_bool_math_2.inputs[1])
                link(node_bool_math_2.outputs[0],
                     bool_group_out.inputs["bool_chain_out"])
                return bool_group_data

        def add_bool_chain_node():
            obj = bpy.context.active_object
            # try to get the Molecular Nodes mofier, if not create one and select it
            # if already exists, just select it
            try:
                node_mod = obj.modifiers['MolecularNodes']
            except:
                node_mod = None
            if node_mod == None:
                node_mod = obj.modifiers.new("MolecularNodes", "NODES")
                obj.modifiers.active = node_mod
            else:
                obj.modifiers.active = node_mod
            try:
                bool_chain_data = bpy.data.node_groups['MOL_utils_bool_chain']
            except:
                bool_chain_data = None
            if bool_chain_data == None:
                bool_chain_data = create_bool_chain_data()

            # now that the data block is checked and setup, create a blank
            # group node and link the data block to the node.
            new_node = node_mod.node_group.nodes.new("GeometryNodeGroup")
            new_node.node_tree = bool_chain_data
            return new_node

        # add_bool_chain_node()
        def create_node_group(node_name, input_list, label_prefix="Chain "):
            """
            Given a an input_list, will create a node which takes an Integer input, 
            and has a boolean tick box for each item in the input list. The outputs will
            be the resulting selection and the inversion of the selection.
            Can contain a prefix for the resulting labels. Mostly used for constructing 
            chain selections when required for specific proteins.
            """
            # get the active object, might need to change to taking an object as an input
            # and making it active isntead, to be more readily applied to multiple objects
            obj = bpy.context.active_object
            # try to get the Molecular Nodes modifier and select it, if not create one and select it
            try:
                node_mod = obj.modifiers['MolecularNodes']
            except:
                node_mod = None
            if node_mod == None:
                node_mod = obj.modifiers.new("MolecularNodes", "NODES")
                obj.modifiers.active = node_mod
            else:
                obj.modifiers.active = node_mod
            # link shortcut for creating links between nodes
            link = node_mod.node_group.links.new
            # create the custom node group data block, where everything will go
            # also create the required group node input and position it
            chain_group = bpy.data.node_groups.new(node_name,
                                                   "GeometryNodeTree")
            chain_group_in = chain_group.nodes.new("NodeGroupInput")
            chain_group_in.location = [-200, 0]
            # create an input on group node input, which will take the field of integers
            # for selection against
            chain_group.inputs.new("NodeSocketInt", "chain_number")
            # create a boolean input for the group for each item in the list
            for chain_name in input_list:
                # create a boolean input for the name, and name it whatever the chain chain name is
                chain_group.inputs.new("NodeSocketBool",
                                       str(label_prefix) + str(chain_name))
            # shortcut for creating new nodes
            new_node = chain_group.nodes.new
            # distance horizontally to space all of the created nodes
            node_sep_dis = 180
            counter = 0
            for chain_name in input_list:
                current_node = chain_group.nodes.new("GeometryNodeGroup")
                current_node.node_tree = create_bool_chain_data()
                current_node.location = [counter * node_sep_dis, 200]
                current_node.inputs[
                    "number_matched"].default_value = counter + 1
                group_link = chain_group.links.new

                group_link(chain_group_in.outputs['chain_number'],
                           current_node.inputs["number_chain_in"])
                group_link(chain_group_in.outputs[counter + 1],
                           current_node.inputs["bool_include"])

                if counter > 0:
                    group_link(previous_node.outputs['number_chain_out'],
                               current_node.inputs['number_chain_in'])
                    group_link(previous_node.outputs['bool_chain_out'],
                               current_node.inputs['bool_chain_in'])

                previous_node = current_node
                counter += 1

            chain_group_out = chain_group.nodes.new("NodeGroupOutput")
            chain_group_out.location = [(counter + 1) * node_sep_dis, 200]
            chain_group.outputs.new("NodeSocketBool", "Selection")
            chain_group.outputs.new("NodeSocketBool", "Inverted")

            group_link(current_node.outputs['bool_chain_out'],
                       chain_group_out.inputs['Selection'])
            bool_math = chain_group.nodes.new("FunctionNodeBooleanMath")
            bool_math.location = [counter * node_sep_dis, 50]
            bool_math.operation = "NOT"
            group_link(current_node.outputs['bool_chain_out'],
                       bool_math.inputs[0])
            group_link(bool_math.outputs[0],
                       chain_group_out.inputs['Inverted'])
            # create an empty node group group inside of the node tree
            # link the just-created custom node group data to the node group in the tree
            new_node_group = node_mod.node_group.nodes.new("GeometryNodeGroup")
            new_node_group.node_tree = bpy.data.node_groups[chain_group.name]
            # resize the newly created node to be a bit wider
            node_mod.node_group.nodes[-1].width = 200

        # the chain_id_list and output_name are passed in from the operator when it is called
        # these are custom properties that are associated with the object when it is initial created
        chain_list = chain_id_list
        node_name = "MOL_" + str(output_name) + "_selection_chain"
        # finally make the selection node!
        create_node_group(node_name, chain_list)
        node = bpy.context.selected_nodes[0]
        bpy.ops.transform.translate('INVOKE_DEFAULT')
        return {"FINISHED"}

    def invoke(self, context, event):

        return self.execute(context)


class SNA_OT_Mol_Pipes_477A1(bpy.types.Operator):
    bl_idname = "sna.mol_pipes_477a1"
    bl_label = "MOL_pipes"
    bl_description = "Some documentation for this operator!"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        sna_append_add_node_3229D('MOL_pipes')
        return {"FINISHED"}

    def invoke(self, context, event):

        return self.execute(context)


class SNA_OT_Mol_Utils_Backup_Mesh_39095(bpy.types.Operator):
    bl_idname = "sna.mol_utils_backup_mesh_39095"
    bl_label = "MOL_utils_backup_mesh"
    bl_description = "Some documentation for this operator!"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        sna_append_add_node_3229D('MOL_utils_backup_mesh')
        return {"FINISHED"}

    def invoke(self, context, event):

        return self.execute(context)


class SNA_OT_Mol_Vertex_83676(bpy.types.Operator):
    bl_idname = "sna.mol_vertex_83676"
    bl_label = "MOL_vertex"
    bl_description = "Some documentation for this operator!"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        sna_append_add_node_3229D('MOL_vertex')
        return {"FINISHED"}

    def invoke(self, context, event):

        return self.execute(context)


class SNA_OT_Mol_Utils_Switch_Float_77Abc(bpy.types.Operator):
    bl_idname = "sna.mol_utils_switch_float_77abc"
    bl_label = "MOL_utils_switch_float"
    bl_description = "Some documentation for this operator!"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        sna_append_add_node_3229D('MOL_utils_switch_float')
        return {"FINISHED"}

    def invoke(self, context, event):

        return self.execute(context)


class SNA_OT_Mol_Utils_Pick_Instance_5Fcd9(bpy.types.Operator):
    bl_idname = "sna.mol_utils_pick_instance_5fcd9"
    bl_label = "MOL_utils_pick_instance"
    bl_description = "Some documentation for this operator!"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        sna_append_add_node_3229D('MOL_utils_pick_instance')
        return {"FINISHED"}

    def invoke(self, context, event):

        return self.execute(context)


class SNA_OT_Mol_Utils_Bool_Chain_C80C6(bpy.types.Operator):
    bl_idname = "sna.mol_utils_bool_chain_c80c6"
    bl_label = "MOL_utils_bool_chain"
    bl_description = "Some documentation for this operator!"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        sna_append_add_node_3229D('MOL_utils_bool_chain')
        return {"FINISHED"}

    def invoke(self, context, event):

        return self.execute(context)


class SNA_OT_Mol_Utils_Primitive_Distance_Probe_8815A(bpy.types.Operator):
    bl_idname = "sna.mol_utils_primitive_distance_probe_8815a"
    bl_label = "MOL_utils_primitive_distance_probe"
    bl_description = "Some documentation for this operator!"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        sna_append_add_node_3229D('MOL_utils_primitive_distance_probe')
        return {"FINISHED"}

    def invoke(self, context, event):

        return self.execute(context)


class SNA_OT_Mol_Style_Colour_A418B(bpy.types.Operator):
    bl_idname = "sna.mol_style_colour_a418b"
    bl_label = "MOL_style_colour"
    bl_description = "Some documentation for this operator!"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        sna_append_add_node_3229D('MOL_style_colour')
        return {"FINISHED"}

    def invoke(self, context, event):

        return self.execute(context)


class SNA_OT_Mol_Style_Manual_Colour_71144(bpy.types.Operator):
    bl_idname = "sna.mol_style_manual_colour_71144"
    bl_label = "MOL_style_manual_colour"
    bl_description = "Some documentation for this operator!"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        sna_append_add_node_3229D('MOL_style_manual_colour')
        return {"FINISHED"}

    def invoke(self, context, event):

        return self.execute(context)


class SNA_OT_Mol_Style_Surface_8Dc5E(bpy.types.Operator):
    bl_idname = "sna.mol_style_surface_8dc5e"
    bl_label = "MOL_style_surface"
    bl_description = "Some documentation for this operator!"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        sna_append_add_node_3229D('MOL_style_surface')
        return {"FINISHED"}

    def invoke(self, context, event):

        return self.execute(context)


class SNA_MT_1C944(bpy.types.Menu):
    bl_idname = "SNA_MT_1C944"
    bl_label = ""

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw(self, context):
        layout = self.layout.column_flow(columns=1)
        op = layout.operator('sna.mol_style_colour_a418b',
                             text='Style Colour',
                             icon_value=0,
                             emboss=True,
                             depress=False)
        op = layout.operator('sna.mol_style_manual_colour_71144',
                             text='Style Colour Manual',
                             icon_value=0,
                             emboss=True,
                             depress=False)
        op = layout.operator('sna.mol_style_surface_8dc5e',
                             text='Style Surface',
                             icon_value=0,
                             emboss=True,
                             depress=False)

        op = layout.operator('sna.mol_atoms_eevee_e802b',
                             text='Atoms EEVEE',
                             icon_value=0,
                             emboss=True,
                             depress=False)
        op = layout.operator('sna.mol_map_range_f3dde',
                             text='Map Range',
                             icon_value=0,
                             emboss=True,
                             depress=False)


class SNA_OT_Mol_Atoms_Eevee_E802B(bpy.types.Operator):
    bl_idname = "sna.mol_atoms_eevee_e802b"
    bl_label = "MOL_atoms_EEVEE"
    bl_description = "Some documentation for this operator!"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        sna_append_add_node_3229D('MOL_atoms_EEVEE')
        return {"FINISHED"}

    def invoke(self, context, event):

        return self.execute(context)


class SNA_OT_Mol_Map_Range_F3Dde(bpy.types.Operator):
    bl_idname = "sna.mol_map_range_f3dde"
    bl_label = "MOL_map_range"
    bl_description = "Some documentation for this operator!"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        sna_append_add_node_3229D('MOL_map_range')
        return {"FINISHED"}

    def invoke(self, context, event):

        return self.execute(context)


class SNA_MT_47239(bpy.types.Menu):
    bl_idname = "SNA_MT_47239"
    bl_label = ""

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw(self, context):
        layout = self.layout.column_flow(columns=1)
        op = layout.operator('sna.mol_pipes_477a1',
                             text='Pipes',
                             icon_value=0,
                             emboss=True,
                             depress=False)
        op = layout.operator('sna.mol_utils_backup_mesh_39095',
                             text='Backup Mesh',
                             icon_value=0,
                             emboss=True,
                             depress=False)
        op = layout.operator('sna.mol_vertex_83676',
                             text='Vertex',
                             icon_value=0,
                             emboss=True,
                             depress=False)
        op = layout.operator('sna.mol_utils_switch_float_77abc',
                             text='Switch Float',
                             icon_value=0,
                             emboss=True,
                             depress=False)
        op = layout.operator('sna.mol_utils_pick_instance_5fcd9',
                             text='Pick Instance',
                             icon_value=0,
                             emboss=True,
                             depress=False)
        op = layout.operator('sna.mol_utils_bool_chain_c80c6',
                             text='Boolean Chain',
                             icon_value=0,
                             emboss=True,
                             depress=False)
        op = layout.operator('sna.mol_utils_primitive_distance_probe_8815a',
                             text='Distance Probe',
                             icon_value=0,
                             emboss=True,
                             depress=False)


def register():

    global _icons
    _icons = bpy.utils.previews.new()
    bpy.types.Scene.sna_pdb_code = bpy.props.StringProperty(
        name='pdb_code',
        description='The PDB ID of the structre you would like to download.',
        default='1bna',
        subtype='NONE',
        maxlen=0)
    bpy.types.Scene.sna_nanometre_scale = bpy.props.FloatProperty(
        name='nanometre_scale',
        description=
        'Scale the model so that one angstrom is this size in metres.',
        default=1.0,
        subtype='NONE',
        unit='LENGTH',
        step=3,
        precision=3)
    bpy.types.Scene.sna_pdb_path = bpy.props.StringProperty(
        name='pdb_path',
        description='File path to .pdb file.',
        default='',
        subtype='FILE_PATH',
        maxlen=0)
    bpy.types.Scene.sna_molecule_name = bpy.props.StringProperty(
        name='molecule_name',
        description='',
        default='',
        subtype='NONE',
        maxlen=0)
    bpy.types.Scene.sna_create_bonds = bpy.props.BoolProperty(
        name='create_bonds', description='', default=False)
    bpy.types.Scene.sna_connect_cutoff = bpy.props.FloatProperty(
        name='connect_cutoff',
        description='',
        default=0.3499999940395355,
        subtype='NONE',
        unit='NONE',
        step=3,
        precision=2)
    bpy.types.Scene.sna_build_assembly = bpy.props.BoolProperty(
        name='build_assembly', description='', default=False)
    bpy.types.Scene.sna_build_assembly_id = bpy.props.IntProperty(
        name='build_assembly_id',
        description='',
        default=1,
        subtype='NONE',
        min=1)

    bpy.utils.register_class(SNA_OT_Mol_Atomic_Properties_30300)
    bpy.utils.register_class(SNA_OT_Mol_Scale_Radii_1163F)
    bpy.utils.register_class(SNA_OT_Mol_Find_Bonds_58203)
    bpy.utils.register_class(SNA_MT_43F2D)
    bpy.types.NODE_MT_add.append(sna_add_to_node_mt_add_EDA2B)
    bpy.utils.register_class(SNA_OT_Mol_Animate_C0484)
    bpy.utils.register_class(SNA_OT_Mol_Animate_Frames_036E7)
    bpy.utils.register_class(SNA_OT_Mol_Noise_823C7)
    bpy.utils.register_class(SNA_OT_Mol_Object_Effect_0186D)
    bpy.utils.register_class(SNA_OT_Mol_Center_Atom_C6F3F)
    bpy.utils.register_class(SNA_MT_E081B)
    bpy.utils.register_class(SNA_OT_Mol_Points_Volume_88829)
    bpy.utils.register_class(SNA_OT_Mol_Selection_Aa_Name_E7B4F)
    bpy.utils.register_class(SNA_MT_B7C1D)
    bpy.utils.register_class(SNA_MT_F5083)
    bpy.utils.register_class(SNA_AddonPreferences_9D182)
    bpy.utils.register_class(SNA_OT_Install_Atomium_Bd760)
    bpy.utils.register_class(SNA_PT_MOLECULAR_NODES_86768)
    bpy.utils.register_class(SNA_OT_Import_Protein_Fetch_Pdb_4Cf80)
    bpy.utils.register_class(SNA_OT_Import_Protein_Local_Ecb16)
    bpy.utils.register_class(SNA_OT_Ops_Chain_Selection_5Cf76)
    bpy.utils.register_class(SNA_OT_Mol_Pipes_477A1)
    bpy.utils.register_class(SNA_OT_Mol_Utils_Backup_Mesh_39095)
    bpy.utils.register_class(SNA_OT_Mol_Vertex_83676)
    bpy.utils.register_class(SNA_OT_Mol_Utils_Switch_Float_77Abc)
    bpy.utils.register_class(SNA_OT_Mol_Utils_Pick_Instance_5Fcd9)
    bpy.utils.register_class(SNA_OT_Mol_Utils_Bool_Chain_C80C6)
    bpy.utils.register_class(SNA_OT_Mol_Utils_Primitive_Distance_Probe_8815A)
    bpy.utils.register_class(SNA_OT_Mol_Style_Colour_A418B)
    bpy.utils.register_class(SNA_OT_Mol_Style_Manual_Colour_71144)
    bpy.utils.register_class(SNA_OT_Mol_Style_Surface_8Dc5E)
    bpy.utils.register_class(SNA_MT_1C944)
    bpy.utils.register_class(SNA_OT_Mol_Atoms_Eevee_E802B)
    bpy.utils.register_class(SNA_OT_Mol_Map_Range_F3Dde)
    bpy.utils.register_class(SNA_MT_47239)


def unregister():

    global _icons
    bpy.utils.previews.remove(_icons)

    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    for km, kmi in addon_keymaps.values():
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    del bpy.types.Scene.sna_build_assembly_id
    del bpy.types.Scene.sna_build_assembly
    del bpy.types.Scene.sna_connect_cutoff
    del bpy.types.Scene.sna_create_bonds
    del bpy.types.Scene.sna_molecule_name
    del bpy.types.Scene.sna_pdb_path
    del bpy.types.Scene.sna_nanometre_scale
    del bpy.types.Scene.sna_pdb_code

    bpy.utils.unregister_class(SNA_OT_Mol_Atomic_Properties_30300)
    bpy.utils.unregister_class(SNA_OT_Mol_Scale_Radii_1163F)
    bpy.utils.unregister_class(SNA_OT_Mol_Find_Bonds_58203)
    bpy.utils.unregister_class(SNA_MT_43F2D)
    bpy.types.NODE_MT_add.remove(sna_add_to_node_mt_add_EDA2B)
    bpy.utils.unregister_class(SNA_OT_Mol_Animate_C0484)
    bpy.utils.unregister_class(SNA_OT_Mol_Animate_Frames_036E7)
    bpy.utils.unregister_class(SNA_OT_Mol_Noise_823C7)
    bpy.utils.unregister_class(SNA_OT_Mol_Object_Effect_0186D)
    bpy.utils.unregister_class(SNA_OT_Mol_Center_Atom_C6F3F)
    bpy.utils.unregister_class(SNA_MT_E081B)
    bpy.utils.unregister_class(SNA_OT_Mol_Points_Volume_88829)
    bpy.utils.unregister_class(SNA_OT_Mol_Selection_Aa_Name_E7B4F)
    bpy.utils.unregister_class(SNA_MT_B7C1D)
    bpy.utils.unregister_class(SNA_MT_F5083)
    bpy.utils.unregister_class(SNA_AddonPreferences_9D182)
    bpy.utils.unregister_class(SNA_OT_Install_Atomium_Bd760)
    bpy.utils.unregister_class(SNA_PT_MOLECULAR_NODES_86768)
    bpy.utils.unregister_class(SNA_OT_Import_Protein_Fetch_Pdb_4Cf80)
    bpy.utils.unregister_class(SNA_OT_Import_Protein_Local_Ecb16)
    bpy.utils.unregister_class(SNA_OT_Ops_Chain_Selection_5Cf76)
    bpy.utils.unregister_class(SNA_OT_Mol_Pipes_477A1)
    bpy.utils.unregister_class(SNA_OT_Mol_Utils_Backup_Mesh_39095)
    bpy.utils.unregister_class(SNA_OT_Mol_Vertex_83676)
    bpy.utils.unregister_class(SNA_OT_Mol_Utils_Switch_Float_77Abc)
    bpy.utils.unregister_class(SNA_OT_Mol_Utils_Pick_Instance_5Fcd9)
    bpy.utils.unregister_class(SNA_OT_Mol_Utils_Bool_Chain_C80C6)
    bpy.utils.unregister_class(SNA_OT_Mol_Utils_Primitive_Distance_Probe_8815A)
    bpy.utils.unregister_class(SNA_OT_Mol_Style_Colour_A418B)
    bpy.utils.unregister_class(SNA_OT_Mol_Style_Manual_Colour_71144)
    bpy.utils.unregister_class(SNA_OT_Mol_Style_Surface_8Dc5E)
    bpy.utils.unregister_class(SNA_MT_1C944)
    bpy.utils.unregister_class(SNA_OT_Mol_Atoms_Eevee_E802B)
    bpy.utils.unregister_class(SNA_OT_Mol_Map_Range_F3Dde)
    bpy.utils.unregister_class(SNA_MT_47239)
